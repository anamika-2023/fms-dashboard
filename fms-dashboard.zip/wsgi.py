# wsgi.py — PythonAnywhere ke liye required file
# FastAPI (ASGI) ko PythonAnywhere ke WSGI server ke saath connect karta hai

from a2wsgi import ASGIMiddleware
from app import app as asgi_app

application = ASGIMiddleware(asgi_app)
