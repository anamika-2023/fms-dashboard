// ═══════════════════════════════════════════════════════════
// FMS Dashboard — Client-Side Filtering Engine (INSTANT MODE)
// All tasks loaded ONCE, filtering happens in browser (<50ms)
// ═══════════════════════════════════════════════════════════
let ALL_TASKS = [];
let FMS_LIST = [];
let DOERS_LIST = [];
let currentPreset = "ALL_TIME";
let chartWorkload = null;
let chartScore = null;
let taskSearchQuery = "";
let ENQUIRY_PIPELINE = [];
let CURRENT_ENQ_VIEW = "steps";
let PAYMENT_CRM = [];
let CURRENT_PAY_DATE_MODE = "overdue"; // "overdue" or "manual"

document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons();
    loadAllTasks(false);
});

async function loadAllTasks(forceRefresh) {
    showLoading(true, forceRefresh ? "Syncing from Google Sheets..." : "Loading data...");
    try {
        const resp = await fetch(`/api/all_tasks?refresh=${forceRefresh}`);
        const data = await resp.json();
        ALL_TASKS  = data.tasks || [];
        FMS_LIST   = data.fms_list || [];
        DOERS_LIST = data.doers || [];
        ENQUIRY_PIPELINE = data.enquiry_pipeline || [];
        PAYMENT_CRM = data.payment_crm || [];
        populateDropdowns();
        applyPreset("YESTERDAY", false);
        document.getElementById("syncStatus").innerHTML = `
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse mr-2"></span>
            ${forceRefresh ? "Synced Just Now" : "Live Google Sheets Connected"}
        `;
    } catch(e) {
        console.error("Error loading tasks:", e);
        document.getElementById("syncStatus").innerHTML = `
            <span class="w-2.5 h-2.5 rounded-full bg-rose-500 mr-2"></span>Error loading`;
    } finally { showLoading(false); }
}

function showLoading(on, msg) {
    const btn = document.getElementById("btnSubmitFilter");
    if (!btn) return;
    if (on) {
        btn.innerHTML = `<i data-lucide="loader-2" class="w-4 h-4 animate-spin"></i><span>${msg || "Loading..."}</span>`;
    } else {
        btn.innerHTML = `<i data-lucide="search" class="w-4 h-4"></i><span>View Report</span>`;
    }
    lucide.createIcons();
}

function populateDropdowns() {
    const fmsSelect = document.getElementById("filterFms");
    fmsSelect.innerHTML = '<option value="ALL">All 8 FMS (Combined Report)</option>';
    FMS_LIST.forEach(item => {
        const opt = document.createElement("option");
        opt.value = item.id; opt.textContent = item.name;
        fmsSelect.appendChild(opt);
    });
    fmsSelect.onchange = onFmsChange;
    updateDoerDropdown();
}

function updateDoerDropdown() {
    const fmsSelect = document.getElementById("filterFms");
    const fmsFilter = fmsSelect ? fmsSelect.value : "ALL";
    const doerSelect = document.getElementById("filterDoer");
    if (!doerSelect) return;
    const currentVal = doerSelect.value;
    
    const validDoers = new Set();
    for (const t of ALL_TASKS) {
        if (fmsFilter === "ALL" || t.fi === fmsFilter) {
            if (t.do && t.do !== "UNASSIGNED") validDoers.add(t.do);
        }
    }
    
    doerSelect.innerHTML = '<option value="ALL">All Doers</option>';
    Array.from(validDoers).sort().forEach(d => {
        const opt = document.createElement("option");
        opt.value = d; opt.textContent = d;
        doerSelect.appendChild(opt);
    });
    
    if (validDoers.has(currentVal)) {
        doerSelect.value = currentVal;
    } else {
        doerSelect.value = "ALL";
    }
}

function onFmsChange() {
    updateDoerDropdown();
    renderDashboardFromCache();
}

function loadReport() {
    updateDoerDropdown();
    renderDashboardFromCache();
}

function applyPreset(preset, andRender = true) {
    currentPreset = preset;
    ["btnPresetToday","btnPresetYesterday","btnPresetThisWeek","btnPresetLastWeek","btnPresetThisMonth","btnPresetLastMonth","btnPresetAllTime"].forEach(id => {
        const btn = document.getElementById(id);
        if (btn) btn.className = "preset-btn-inactive px-3.5 py-1.5 rounded-xl font-bold transition text-xs border";
    });
    const map = {
        "TODAY":"btnPresetToday",
        "YESTERDAY":"btnPresetYesterday",
        "THIS_WEEK":"btnPresetThisWeek",
        "LAST_WEEK":"btnPresetLastWeek",
        "THIS_MONTH":"btnPresetThisMonth",
        "LAST_MONTH":"btnPresetLastMonth",
        "ALL_TIME":"btnPresetAllTime"
    };
    const activeBtn = document.getElementById(map[preset]);
    if (activeBtn) activeBtn.className = "preset-btn-active px-3.5 py-1.5 rounded-xl font-bold transition text-xs border shadow-sm";

    const si = document.getElementById("startDate");
    const ei = document.getElementById("endDate");
    const today = new Date();
    const fmt = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    const fmtD = d => `${String(d.getDate()).padStart(2,'0')}-${String(d.getMonth()+1).padStart(2,'0')}-${d.getFullYear()}`;
    const lbl = document.getElementById("activeFilterLabel");
    if (preset === "TODAY") {
        si.value = fmt(today); ei.value = fmt(today);
        if (lbl) lbl.innerHTML = `Currently showing: <strong>Today's Report (${fmtD(today)})</strong>`;
    } else if (preset === "YESTERDAY") {
        const y = new Date(today); y.setDate(y.getDate()-1);
        si.value = fmt(y); ei.value = fmt(y);
        if (lbl) lbl.innerHTML = `Currently showing: <strong>Yesterday's Report (${fmtD(y)})</strong>`;
    } else if (preset === "THIS_WEEK") {
        const mon = new Date(today); const day = mon.getDay();
        mon.setDate(mon.getDate() - day + (day===0?-6:1));
        si.value = fmt(mon); ei.value = fmt(today);
        if (lbl) lbl.innerHTML = `Currently showing: <strong>This Week (${fmtD(mon)} to ${fmtD(today)})</strong>`;
    } else if (preset === "LAST_WEEK") {
        const mon = new Date(today); const day = mon.getDay();
        mon.setDate(mon.getDate() - day + (day===0?-6:1) - 7);
        const sun = new Date(mon); sun.setDate(mon.getDate()+6);
        si.value = fmt(mon); ei.value = fmt(sun);
        if (lbl) lbl.innerHTML = `Currently showing: <strong>Last Week (${fmtD(mon)} to ${fmtD(sun)})</strong>`;
    } else if (preset === "THIS_MONTH") {
        const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
        si.value = fmt(firstDay); ei.value = fmt(today);
        if (lbl) lbl.innerHTML = `Currently showing: <strong>This Month (${fmtD(firstDay)} to ${fmtD(today)})</strong>`;
    } else if (preset === "LAST_MONTH") {
        const firstDay = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        const lastDay = new Date(today.getFullYear(), today.getMonth(), 0);
        si.value = fmt(firstDay); ei.value = fmt(lastDay);
        if (lbl) lbl.innerHTML = `Currently showing: <strong>Last Month (${fmtD(firstDay)} to ${fmtD(lastDay)})</strong>`;
    } else if (preset === "ALL_TIME") {
        si.value = ""; ei.value = "";
        if (lbl) lbl.innerHTML = `Currently showing: <strong>All Time Data</strong>`;
    }
    if (andRender) renderDashboardFromCache();
}

function onCustomDateInput() {
    currentPreset = "CUSTOM";
    ["btnPresetToday","btnPresetYesterday","btnPresetThisWeek","btnPresetLastWeek","btnPresetThisMonth","btnPresetLastMonth","btnPresetAllTime"].forEach(id => {
        const btn = document.getElementById(id);
        if (btn) btn.className = "preset-btn-inactive px-3.5 py-1.5 rounded-xl font-bold transition text-xs border";
    });
    const start = document.getElementById("startDate").value;
    const end   = document.getElementById("endDate").value;
    const lbl   = document.getElementById("activeFilterLabel");
    if (start && end && lbl) {
        lbl.innerHTML = `Currently showing: <strong>Custom Range (${start} to ${end})</strong>`;
        renderDashboardFromCache();
    }
}

function submitFilter() { renderDashboardFromCache(); }

async function refreshData() {
    const btn  = document.getElementById("btnRefresh");
    const icon = document.getElementById("refreshIcon");
    if (icon) icon.classList.add("animate-spin");
    if (btn)  btn.disabled = true;
    try { await loadAllTasks(true); }
    catch(e) { console.error("Refresh error:", e); }
    finally {
        if (icon) icon.classList.remove("animate-spin");
        if (btn)  btn.disabled = false;
    }
}

function parseLocalDate(s) {
    if (!s) return null;
    try {
        if (typeof s !== "string") return null;
        let str = s.trim();
        if (str.includes("T")) str = str.split("T")[0];
        if (str.includes("/")) {
            const parts = str.split("/");
            if (parts.length === 3) {
                const [d, m, y] = parts.map(Number);
                return new Date(y, m - 1, d, 0, 0, 0);
            }
        }
        const parts = str.split(" ");
        const ymd = parts[0].split("-").map(Number);
        if (ymd.length === 3) {
            const [y, m, d] = ymd;
            if (parts[1]) {
                const [h, mi] = parts[1].split(":").map(Number);
                return new Date(y, m - 1, d, h, mi, 0);
            }
            return new Date(y, m - 1, d, 0, 0, 0);
        }
        const fallback = new Date(str);
        return isNaN(fallback.getTime()) ? null : fallback;
    } catch(e) { return null; }
}

function parseDateRange() {
    const sv = document.getElementById("startDate").value;
    const ev = document.getElementById("endDate").value;
    let startDt=null, endDt=null;
    if (sv) { const [y,m,d]=sv.split("-").map(Number); startDt=new Date(y,m-1,d,0,0,0); }
    if (ev) { const [y,m,d]=ev.split("-").map(Number); endDt=new Date(y,m-1,d,23,59,59); }
    return { startDt, endDt };
}

function renderDashboardFromCache() {
    if (!ALL_TASKS.length) return;
    const fmsFilter    = document.getElementById("filterFms").value;
    const doerFilter   = document.getElementById("filterDoer").value;
    const statusFilter = document.getElementById("filterStatus").value;
    const { startDt, endDt } = parseDateRange();
    const now = new Date();

    const filtered = []; const advanceDoneIds = new Set();
    for (const t of ALL_TASKS) {
        if (fmsFilter !== "ALL" && t.fi !== fmsFilter) continue;
        if (doerFilter !== "ALL" && t.do !== doerFilter) continue;
        if (statusFilter !== "ALL") {
            if (statusFilter==="COMPLETED" && !t.cp) continue;
            if (statusFilter==="PENDING"   &&  t.cp) continue;
            if (statusFilter==="ON_TIME"   && !t.ot) continue;
            if (statusFilter==="DELAYED"   && (t.ot||!t.cp)) continue;
            if (statusFilter==="OVERDUE"   && t.sx!=="Pending Overdue") continue;
        }
        if (startDt||endDt) {
            const p=parseLocalDate(t.pd); const a=parseLocalDate(t.ad);
            const pIn = p&&(!startDt||p>=startDt)&&(!endDt||p<=endDt);
            const aIn = a&&(!startDt||a>=startDt)&&(!endDt||a<=endDt);
            if (!pIn&&!aIn) continue;
            if (aIn&&!pIn&&t.cp) advanceDoneIds.add(t.id);
        }
        filtered.push(t);
    }

    const doerMap = {};
    const relevantDoers = new Set();
    for (const t of ALL_TASKS) {
        if (fmsFilter === "ALL" || t.fi === fmsFilter) {
            if (t.do && t.do !== "UNASSIGNED") relevantDoers.add(t.do);
        }
    }
    for (const d of relevantDoers) {
        doerMap[d] = {
            doer: d, total_assigned: 0, total_completed: 0, ontime_completed: 0,
            delayed_completed: 0, advance_done: 0, total_pending: 0, pending_overdue: 0,
            work_done_score: 0, ontime_delay_score: 0, score_percentage: 0
        };
    }

    for (const t of filtered) {
        const d = t.do;
        if (!doerMap[d]) continue;
        const dm = doerMap[d];
        if (advanceDoneIds.has(t.id)) { dm.advance_done++; dm.total_completed++; if(t.ot) dm.ontime_completed++; else dm.delayed_completed++; continue; }
        const p = parseLocalDate(t.pd); const a = parseLocalDate(t.ad);
        const pIn = p && (!startDt || p >= startDt) && (!endDt || p <= endDt);
        if (pIn) {
            dm.total_assigned++;
            if (t.cp && (!endDt || !a || a <= endDt)) { dm.total_completed++; if(t.ot) dm.ontime_completed++; else dm.delayed_completed++; }
            else dm.total_pending++;
        }
    }

    const cutoff    = endDt || new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
    const asOfLimit = endDt || now;
    for (const t of ALL_TASKS) {
        if (fmsFilter !== "ALL" && t.fi !== fmsFilter) continue;
        if (doerFilter !== "ALL" && t.do !== doerFilter) continue;
        if (!doerMap[t.do]) continue;
        const p = parseLocalDate(t.pd); const a = parseLocalDate(t.ad);
        const isCompAsOf = t.cp && (!endDt || !a || a <= asOfLimit);
        if (!isCompAsOf && p && p <= cutoff) doerMap[t.do].pending_overdue++;
    }

    const doerList = Object.values(doerMap).filter(dm => {
        return (dm.total_assigned > 0 || dm.total_completed > 0 || dm.pending_overdue > 0);
    }).map(dm => {
        dm.score_percentage   = dm.total_assigned>0 ? +(dm.ontime_completed/dm.total_assigned*100).toFixed(1) : 0;
        dm.work_done_score    = dm.total_assigned>0 ? +Math.max(0,(dm.total_assigned-dm.total_completed)/dm.total_assigned*100).toFixed(1) : 0;
        dm.ontime_delay_score = dm.total_completed>0 ? +Math.max(0,(dm.total_completed-dm.ontime_completed)/dm.total_completed*100).toFixed(1) : 0;
        return dm;
    }).sort((a,b)=>b.total_assigned-a.total_assigned||b.score_percentage-a.score_percentage);

    const fmsMap = {};
    for (const f of FMS_LIST) fmsMap[f.id]={fms_id:f.id,fms_name:f.name,total_tasks:0,completed_tasks:0,ontime_tasks:0,pending_tasks:0,overall_score:0};
    for (const t of filtered) {
        if (!fmsMap[t.fi]) continue;
        fmsMap[t.fi].total_tasks++;
        if (t.cp) { fmsMap[t.fi].completed_tasks++; if(t.ot) fmsMap[t.fi].ontime_tasks++; }
        else fmsMap[t.fi].pending_tasks++;
    }
    const fmsSummaries = Object.values(fmsMap).map(f => {
        if (f.total_tasks>0) f.overall_score = +(f.ontime_tasks/f.total_tasks*100).toFixed(1);
        return f;
    });

    const realFiltered = filtered.filter(t=>!advanceDoneIds.has(t.id));
    const tot     = realFiltered.length;
    const comp    = realFiltered.filter(t=>t.cp).length;
    const ontime  = realFiltered.filter(t=>t.cp&&t.ot).length;
    const delayed = realFiltered.filter(t=>t.cp&&!t.ot).length;
    const pending = realFiltered.filter(t=>!t.cp).length;
    const overdue = realFiltered.filter(t=>t.sx==="Pending Overdue").length;

    const taskItemsOut = filtered.map(t=>({
        id: t.id,
        fms_name:t.fn,tab_name:t.tb,entity_name:t.en,step_name:t.st,
        doer:t.do,planned_date:t.pd,actual_date:t.ad,
        status:advanceDoneIds.has(t.id)?"Advance Done (Extra)":t.sx,
        delay_hours:t.dh,overdue_hours:t.oh,
        so:t.so||"N/A", po:t.po||"N/A", cu:t.cu||"N/A", vn:t.vn||"N/A",
        dd:t.dd||"N/A", dl:t.dl||"N/A", sd:t.sd||"N/A"
    }));

    if (startDt||endDt) {
        const seenIds = new Set(filtered.map(t=>t.id));
        for (const t of ALL_TASKS) {
            if (seenIds.has(t.id)) continue;
            if (fmsFilter!=="ALL"&&t.fi!==fmsFilter) continue;
            if (doerFilter!=="ALL"&&t.do!==doerFilter) continue;
            const p=parseLocalDate(t.pd); const a=parseLocalDate(t.ad);
            const isComp = t.cp&&(!endDt||!a||a<=asOfLimit);
            if (!isComp&&p&&p<startDt) {
                seenIds.add(t.id);
                taskItemsOut.push({
                    id: t.id,
                    fms_name:t.fn,tab_name:t.tb,entity_name:t.en,step_name:t.st,
                    doer:t.do,planned_date:t.pd,actual_date:t.ad,
                    status:"Pending Overdue (Past Backlog)",delay_hours:t.dh,overdue_hours:t.oh,
                    so:t.so||"N/A", po:t.po||"N/A", cu:t.cu||"N/A", vn:t.vn||"N/A",
                    dd:t.dd||"N/A", dl:t.dl||"N/A", sd:t.sd||"N/A"
                });
            }
        }
    }

    renderDashboard({
        total_assigned:tot,total_completed:comp,ontime_completed:ontime,
        delayed_completed:delayed,total_pending:pending,pending_overdue:overdue,
        overall_score_percentage:tot>0?+(ontime/tot*100).toFixed(1):0,
        doer_metrics:doerList,fms_summaries:fmsSummaries,task_items:taskItemsOut
    });
}

function getScoreBadge(score, count) {
    if (count === 0) {
        return `<span class="bg-slate-100 text-slate-400 px-2.5 py-0.5 rounded-full text-xs font-semibold">—</span>`;
    }
    if (score === 0) {
        return `<span class="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2.5 py-0.5 rounded-full font-extrabold text-xs">0% ⭐</span>`;
    } else if (score <= 20) {
        return `<span class="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-0.5 rounded-full font-bold text-xs">${score}%</span>`;
    } else if (score <= 50) {
        return `<span class="bg-amber-100 text-amber-800 border border-amber-300 px-2.5 py-0.5 rounded-full font-bold text-xs">${score}%</span>`;
    } else {
        return `<span class="bg-rose-100 text-rose-800 border border-rose-300 px-2.5 py-0.5 rounded-full font-extrabold text-xs">${score}%</span>`;
    }
}

function renderDashboard(data) {
    document.getElementById("kpiAssigned").textContent  = data.total_assigned.toLocaleString();
    document.getElementById("kpiCompleted").textContent = data.total_completed.toLocaleString();
    const compRate = data.total_assigned ? ((data.total_completed/data.total_assigned)*100).toFixed(1) : 0;
    document.getElementById("kpiCompletedSub").textContent = `${compRate}% completion rate`;
    document.getElementById("kpiOntime").textContent    = data.ontime_completed.toLocaleString();
    document.getElementById("kpiOntimeSub").textContent = `${data.delayed_completed.toLocaleString()} delayed completions`;
    document.getElementById("kpiScore").textContent     = `${data.overall_score_percentage}%`;
    document.getElementById("kpiPending").textContent   = data.total_pending.toLocaleString();
    document.getElementById("kpiOverdueSub").textContent= `${data.pending_overdue.toLocaleString()} pending overdue tasks`;

    const tbody = document.getElementById("doerTableBody");
    tbody.innerHTML = "";
    data.doer_metrics.forEach(d => {
        const tr = document.createElement("tr");
        tr.className = "hover:bg-indigo-50/70 transition cursor-pointer border-b border-slate-100";
        tr.onclick = () => filterByDoer(d.doer);
        const wdsBadge = getScoreBadge(d.work_done_score, d.total_assigned);
        const otBadge  = getScoreBadge(d.ontime_delay_score, d.total_completed);
        tr.innerHTML = `
            <td class="py-3 px-3.5 font-bold text-slate-800 flex items-center space-x-2">
                <span class="w-2 h-2 rounded-full ${d.total_assigned>0?'bg-emerald-500':'bg-slate-300'}"></span>
                <span>${d.doer}</span></td>
            <td class="py-3 px-3.5 text-center font-semibold text-slate-700">${d.total_assigned}</td>
            <td class="py-3 px-3.5 text-center font-semibold text-emerald-600">${d.total_completed}</td>
            <td class="py-3 px-3.5 text-center font-semibold text-cyan-600">${d.ontime_completed}</td>
            <td class="py-3 px-3.5 text-center font-semibold ${d.total_pending>0?'text-rose-500 font-bold':'text-slate-400'}">${d.total_pending}</td>
            <td class="py-3 px-3.5 text-center font-bold">${wdsBadge}</td>
            <td class="py-3 px-3.5 text-center font-bold">${otBadge}</td>
            <td class="py-3 px-3.5 text-center font-bold ${d.pending_overdue>0?'text-rose-700':'text-slate-400'}">${d.pending_overdue}</td>`;
        tbody.appendChild(tr);
    });

    const fmsBody = document.getElementById("fmsTableBody");
    fmsBody.innerHTML = "";
    data.fms_summaries.forEach(f => {
        if (f.total_tasks>0) {
            const tr = document.createElement("tr");
            tr.className = "hover:bg-purple-50/70 transition border-b border-slate-100";
            tr.innerHTML = `
                <td class="py-2.5 px-3 font-semibold text-slate-800 text-xs truncate max-w-[140px]" title="${f.fms_name}">${f.fms_name}</td>
                <td class="py-2.5 px-3 text-center text-xs font-bold text-slate-700">${f.total_tasks}</td>
                <td class="py-2.5 px-3 text-center text-xs font-semibold text-emerald-600">${f.completed_tasks}</td>
                <td class="py-2.5 px-3 text-center text-xs font-bold text-purple-700">${f.overall_score}%</td>`;
            fmsBody.appendChild(tr);
        }
    });
    renderTaskTable(data.task_items);
    renderCharts(data);

    const fmsFilter = document.getElementById("filterFms") ? document.getElementById("filterFms").value : "ALL";
    const enqNav = document.getElementById("enquiryViewNav");
    const dashTop = document.getElementById("standardDashboardTop");
    const secTask = document.getElementById("standardTaskSection");
    const secPay = document.getElementById("paymentCrmSection");
    const secPipe = document.getElementById("enquiryPipelineSection");

    if (fmsFilter === "fms_9") {
        if (enqNav) enqNav.classList.add("hidden");
        if (secPipe) secPipe.classList.add("hidden");
        if (dashTop) dashTop.classList.add("hidden");
        if (secTask) secTask.classList.add("hidden");
        if (secPay) {
            secPay.classList.remove("hidden");
            renderPaymentCrm();
        }
    } else {
        if (secPay) secPay.classList.add("hidden");
        if (dashTop) dashTop.classList.remove("hidden");
        if (fmsFilter === "fms_2") {
            if (enqNav) enqNav.classList.remove("hidden");
            if (CURRENT_ENQ_VIEW === "pipeline") {
                if (secPipe) secPipe.classList.remove("hidden");
                if (secTask) secTask.classList.add("hidden");
                renderEnquiryPipeline();
            } else {
                if (secPipe) secPipe.classList.add("hidden");
                if (secTask) secTask.classList.remove("hidden");
            }
        } else {
            if (enqNav) enqNav.classList.add("hidden");
            if (secPipe) secPipe.classList.add("hidden");
            if (secTask) secTask.classList.remove("hidden");
            switchEnquiryView("steps");
        }
    }
}

function filterByDoer(doerName) {
    document.getElementById("filterDoer").value = doerName;
    renderDashboardFromCache();
    const taskSection = document.getElementById("taskTableSection");
    if (taskSection) taskSection.scrollIntoView({ behavior:"smooth", block:"start" });
}

function renderTaskTable(tasks) {
    const tbody = document.getElementById("taskTableBody");
    tbody.innerHTML = "";
    document.getElementById("taskCountBadge").textContent = `${tasks.length} Tasks`;
    const q = taskSearchQuery.toLowerCase();
    const displayed = q ? tasks.filter(t =>
        (t.entity_name&&t.entity_name.toLowerCase().includes(q))||
        (t.step_name&&t.step_name.toLowerCase().includes(q))||
        (t.doer&&t.doer.toLowerCase().includes(q))||
        (t.fms_name&&t.fms_name.toLowerCase().includes(q))||
        (t.so&&t.so.toLowerCase().includes(q))||
        (t.po&&t.po.toLowerCase().includes(q))||
        (t.cu&&t.cu.toLowerCase().includes(q))||
        (t.vn&&t.vn.toLowerCase().includes(q))
    ) : tasks;
    displayed.slice(0,300).forEach(t => {
        const tr = document.createElement("tr");
        tr.className = "hover:bg-indigo-50/80 transition cursor-pointer border-b border-slate-100 text-xs group";
        tr.onclick = () => openOrderDetailModal(t);

        const sx = t.status||"";
        let stBadge = `<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-slate-100 text-slate-700">${sx}</span>`;
        if (sx==="Completed On-Time") stBadge=`<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-emerald-100 text-emerald-800">Completed On-Time</span>`;
        else if (sx==="Completed Delayed") stBadge=`<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-amber-100 text-amber-800">Completed Delayed</span>`;
        else if (sx.includes("Advance Done")) stBadge=`<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-purple-100 text-purple-800">Advance Done (Extra)</span>`;
        else if (sx.includes("Past Backlog")) stBadge=`<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-red-100 text-red-900 border border-red-300">Overdue (Past Backlog)</span>`;
        else if (sx==="Pending Overdue") stBadge=`<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-rose-100 text-rose-800">Pending Overdue</span>`;
        else if (sx==="Pending On-Track") stBadge=`<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-blue-100 text-blue-800">Pending On-Track</span>`;
        let delayText="-";
        if (t.delay_hours>0) delayText=`<span class="text-amber-700 font-bold">${t.delay_hours} hrs delayed</span>`;
        if (t.overdue_hours>0) delayText=`<span class="text-rose-700 font-bold">${t.overdue_hours} hrs overdue</span>`;

        const isEnq = (t.fms_name && t.fms_name.includes("Enquiry")) || t.tab_name === "MASTER" || t.tab_name === "MASTERSHEET" || (t.id && t.id.startsWith("ENQ-"));
        const isReturn = (t.fms_name && t.fms_name.includes("Return")) || t.tab_name === "RETURNFMS" || (t.id && t.id.startsWith("RET-"));
        const isComm = (t.fms_name && t.fms_name.includes("Commission")) || (t.id && t.id.startsWith("COMM-"));
        const isDC = (t.fms_name && t.fms_name.includes("Delivery Challan")) || (t.id && t.id.startsWith("DC-"));
        const isAFS = (t.fms_name && t.fms_name.includes("After Sales")) || (t.id && t.id.startsWith("AFS-"));
        const nameVal = (t.cu && t.cu !== "N/A") ? t.cu : t.entity_name;
        const keyVal = (t.so && t.so !== "N/A") ? t.so : null;

        let badgesHtml = "";
        if (isEnq) {
            const saleVal = t.vn || "In progress";
            const saleLower = saleVal.toLowerCase();
            const saleBadge = saleLower.includes("win") ? "bg-emerald-100 text-emerald-800 border-emerald-300 font-extrabold" :
                              saleLower.includes("loss") ? "bg-rose-100 text-rose-800 border-rose-300 font-bold" :
                              "bg-amber-50 text-amber-800 border-amber-200 font-semibold";
            const revBadge = t.po === "YES" ? '<span class="bg-rose-50 text-rose-700 border border-rose-200 font-bold px-1.5 py-0.2 rounded text-[10px]">Rev: YES</span>' : '<span class="bg-slate-100 text-slate-500 px-1.5 py-0.2 rounded text-[10px]">Rev: NO</span>';
            const statBadge = (t.dl && t.dl !== "N/A") ? `<span class="bg-purple-50 text-purple-700 border border-purple-200 font-bold px-1.5 py-0.2 rounded text-[10px]">Status: ${t.dl}</span>` : '';
            badgesHtml = `
                ${keyVal ? `<span class="bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono font-bold text-[10px]">${keyVal}</span>` : ''}
                <span class="border px-1.5 py-0.2 rounded text-[10px] ${saleBadge}">Sale: ${saleVal}</span>
                ${statBadge}
                ${revBadge}
            `;
        } else if (isReturn) {
            const retKey = t.po !== "N/A" ? t.po : t.entity_name;
            const invVal = t.dd !== "N/A" ? t.dd : null;
            const itemVal = t.vn !== "N/A" ? t.vn : null;
            badgesHtml = `
                <span class="bg-purple-100 text-purple-800 border border-purple-200 font-mono font-bold px-1.5 py-0.2 rounded text-[10px]">Key: ${retKey}</span>
                ${keyVal ? `<span class="bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono font-bold px-1.5 py-0.2 rounded text-[10px]">SO: ${keyVal}</span>` : ''}
                ${invVal ? `<span class="bg-amber-50 text-amber-800 border border-amber-200 font-mono text-[10px]">Inv: ${invVal}</span>` : ''}
                ${itemVal ? `<span class="bg-slate-100 text-slate-700 text-[10px] truncate max-w-[140px]" title="Item: ${itemVal}">📦 ${itemVal}</span>` : ''}
            `;
        } else if (isComm) {
            badgesHtml = `
                <span class="bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono font-bold px-1.5 py-0.2 rounded text-[10px]">ENQ: ${t.so}</span>
                ${t.po && t.po !== 'N/A' ? `<span class="bg-purple-50 text-purple-700 border border-purple-200 font-medium px-1.5 py-0.2 rounded text-[10px] truncate max-w-[140px]" title="Interior: ${t.po}">🎨 ${t.po}</span>` : ''}
                <span class="border px-1.5 py-0.2 rounded text-[10px] ${t.vn.toLowerCase().includes('win') ? 'bg-emerald-100 text-emerald-800 border-emerald-300 font-extrabold' : 'bg-slate-100 text-slate-700'}">${t.vn}</span>
            `;
        } else if (isDC) {
            const dcKey = t.po !== "N/A" ? t.po : t.entity_name;
            const dcNo = t.vn !== "N/A" ? t.vn : null;
            const dcDate = t.dd !== "N/A" ? t.dd : null;
            badgesHtml = `
                <span class="bg-purple-100 text-purple-800 border border-purple-200 font-mono font-bold px-1.5 py-0.2 rounded text-[10px]">Key: ${dcKey}</span>
                ${keyVal ? `<span class="bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono font-bold px-1.5 py-0.2 rounded text-[10px]">SO: ${keyVal}</span>` : ''}
                ${dcNo ? `<span class="bg-emerald-50 text-emerald-800 border border-emerald-200 font-mono font-medium px-1.5 py-0.2 rounded text-[10px]">DC: ${dcNo}</span>` : ''}
                ${dcDate ? `<span class="bg-sky-50 text-sky-800 border border-sky-200 font-mono text-[10px]">Date: ${dcDate}</span>` : ''}
            `;
        } else if (isAFS) {
            const issId = t.so !== "N/A" ? t.so : t.entity_name;
            const visitD = t.dd !== "N/A" ? t.dd : (t.po !== "N/A" && !t.po.includes("Light") ? t.po : null);
            const catVal = t.vn !== "N/A" && t.vn !== "After Sales" ? t.vn : (t.po !== "N/A" && (t.po.includes("Light") || t.po.includes("Smart")) ? t.po : null);
            badgesHtml = `
                <span class="bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono font-bold px-1.5 py-0.2 rounded text-[10px]">Issue: ${issId}</span>
                ${visitD ? `<span class="bg-amber-50 text-amber-800 border border-amber-200 font-mono text-[10px]">Visit: ${visitD}</span>` : ''}
                ${catVal ? `<span class="bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px]">Cat: ${catVal}</span>` : ''}
            `;
        } else {
            const poVal = (t.po && t.po !== "N/A") ? t.po : "N/A";
            const vendorVal = (t.vn && t.vn !== "N/A") ? t.vn : null;
            badgesHtml = `
                ${keyVal ? `<span class="bg-indigo-50 text-indigo-700 border border-indigo-200 px-1.5 py-0.2 rounded font-mono font-bold text-[10px]">${keyVal}</span>` : ''}
                <span class="${poVal !== 'N/A' ? 'bg-amber-50 text-amber-800 border border-amber-200 font-bold' : 'bg-slate-100 text-slate-400 font-medium'} px-1.5 py-0.2 rounded font-mono text-[10px]">PO: ${poVal}</span>
                ${vendorVal ? `<span class="bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.2 rounded font-medium text-[10px] truncate max-w-[140px]" title="Vendor: ${vendorVal}">🏢 ${vendorVal}</span>` : ''}
            `;
        }

        tr.innerHTML = `
            <td class="py-2.5 px-3">
                <span class="font-bold text-indigo-700">${t.fms_name}</span>
                <span class="block text-[10px] text-slate-400 font-medium">${t.tab_name}</span>
            </td>
            <td class="py-2.5 px-3">
                <div class="font-extrabold text-slate-900 group-hover:text-indigo-600 transition text-xs max-w-[240px] truncate" title="${nameVal}">
                    ${nameVal}
                </div>
                <div class="flex flex-wrap gap-1 items-center mt-1">
                    ${badgesHtml}
                </div>
            </td>
            <td class="py-2.5 px-3 font-medium text-slate-700 max-w-[200px] truncate" title="${t.step_name}">${t.step_name}</td>
            <td class="py-2.5 px-3 font-bold text-purple-700 text-center">${t.doer}</td>
            <td class="py-2.5 px-3 text-slate-500 font-mono text-center">${t.planned_date||'-'}</td>
            <td class="py-2.5 px-3 text-slate-500 font-mono text-center">${t.actual_date||'-'}</td>
            <td class="py-2.5 px-3 text-center">${stBadge}</td>
            <td class="py-2.5 px-3 text-center">${delayText}</td>`;
        tbody.appendChild(tr);
    });
}

function openOrderDetailModal(task) {
    const modal = document.getElementById("orderModal");
    if (!modal) return;

    const isEnq = (task.fms_name && task.fms_name.includes("Enquiry")) || task.tab_name === "MASTER" || task.tab_name === "MASTERSHEET" || (task.id && task.id.startsWith("ENQ-"));
    const isReturn = (task.fms_name && task.fms_name.includes("Return")) || task.tab_name === "RETURNFMS" || (task.id && task.id.startsWith("RET-"));
    const isComm = (task.fms_name && task.fms_name.includes("Commission")) || (task.id && task.id.startsWith("COMM-"));
    const isDC = (task.fms_name && task.fms_name.includes("Delivery Challan")) || (task.id && task.id.startsWith("DC-"));
    const isAFS = (task.fms_name && task.fms_name.includes("After Sales")) || (task.id && task.id.startsWith("AFS-"));
    const name = (task.cu && task.cu !== "N/A") ? task.cu : task.entity_name;
    const key = (task.so && task.so !== "N/A") ? task.so : "N/A";
    const card7 = document.getElementById("modalCard7Wrapper");

    if (isEnq) {
        document.getElementById("modalOrderTitle").textContent = `Enquiry: ${key} – ${name}`;
        
        document.getElementById("modalCard1Label").textContent = "Enquiry Name";
        document.getElementById("modalCust").textContent = name;
        
        document.getElementById("modalCard2Label").textContent = "Enquiry Number";
        document.getElementById("modalSO").textContent = key;
        
        document.getElementById("modalCard3Label").textContent = "Revision Required?";
        document.getElementById("modalPO").innerHTML = task.po === "YES" 
            ? `<span class="text-rose-600 font-extrabold">YES (Revision Required)</span>` 
            : `<span class="text-emerald-700 font-bold">NO</span>`;
        
        document.getElementById("modalCard4Label").textContent = "Sale - Win/Loss";
        const saleVal = task.vn || "In progress";
        const saleClass = saleVal.toLowerCase().includes("win") ? "text-emerald-700 font-extrabold" : saleVal.toLowerCase().includes("loss") ? "text-rose-700 font-extrabold" : "text-amber-800 font-bold";
        document.getElementById("modalVendor").innerHTML = `<span class="${saleClass}">${saleVal}</span>`;
        
        document.getElementById("modalCard5Label").textContent = "Enquiry Date";
        document.getElementById("modalDespatch").textContent = task.dd || "N/A";
        
        document.getElementById("modalCard6Label").textContent = "Enquiry Status";
        const statVal = task.dl || "ongoing";
        document.getElementById("modalDelivery").innerHTML = `<span class="uppercase font-bold">${statVal}</span>`;
        
        if (card7) card7.classList.add("hidden");
    } else if (isReturn) {
        const retKey = task.po !== "N/A" ? task.po : (task.dl !== "N/A" ? task.dl : "RETURN");
        document.getElementById("modalOrderTitle").textContent = `Return: ${retKey} – ${name}`;
        
        document.getElementById("modalCard1Label").textContent = "Site Name";
        document.getElementById("modalCust").textContent = name;
        
        document.getElementById("modalCard2Label").textContent = "Unique Key";
        document.getElementById("modalSO").textContent = retKey;
        
        document.getElementById("modalCard3Label").textContent = "SO Number";
        document.getElementById("modalPO").textContent = key;
        
        document.getElementById("modalCard4Label").textContent = "Invoice Number";
        document.getElementById("modalVendor").textContent = task.dd || "N/A";
        
        document.getElementById("modalCard5Label").textContent = "Item Name";
        document.getElementById("modalDespatch").textContent = task.vn || "N/A";
        
        document.getElementById("modalCard6Label").textContent = "Step Assigned To";
        document.getElementById("modalDelivery").innerHTML = `<span class="font-bold text-purple-700">${task.doer || task.do || "Assigned Team"}</span>`;
        
        if (card7) card7.classList.add("hidden");
    } else if (isComm) {
        document.getElementById("modalOrderTitle").textContent = `Commission: ${key} – ${name}`;
        
        document.getElementById("modalCard1Label").textContent = "Enquiry Name";
        document.getElementById("modalCust").textContent = name;
        
        document.getElementById("modalCard2Label").textContent = "Unique Enquiry Number";
        document.getElementById("modalSO").textContent = key;
        
        document.getElementById("modalCard3Label").textContent = "Interior Name";
        document.getElementById("modalPO").textContent = task.po || "N/A";
        
        document.getElementById("modalCard4Label").textContent = "Sale - Win/Loss";
        const saleVal = task.vn || "In progress";
        const saleClass = saleVal.toLowerCase().includes("win") ? "text-emerald-700 font-extrabold" : "text-slate-800 font-bold";
        document.getElementById("modalVendor").innerHTML = `<span class="${saleClass}">${saleVal}</span>`;
        
        document.getElementById("modalCard5Label").textContent = "Step Assigned To";
        document.getElementById("modalDespatch").innerHTML = `<span class="font-bold text-purple-700">${task.doer || task.do || "Assigned Team"}</span>`;
        
        document.getElementById("modalCard6Label").textContent = "FMS System";
        document.getElementById("modalDelivery").innerHTML = `<span class="font-bold text-indigo-800">8. Commission FMS</span>`;
        
        if (card7) card7.classList.add("hidden");
    } else if (isDC) {
        const dcKey = task.po !== "N/A" ? task.po : "DC";
        document.getElementById("modalOrderTitle").textContent = `Delivery Challan: ${dcKey} – ${name}`;
        
        document.getElementById("modalCard1Label").textContent = "SO NAME / Customer";
        document.getElementById("modalCust").textContent = name;
        
        document.getElementById("modalCard2Label").textContent = "Unique Key";
        document.getElementById("modalSO").textContent = dcKey;
        
        document.getElementById("modalCard3Label").textContent = "SO NO";
        document.getElementById("modalPO").textContent = key;
        
        document.getElementById("modalCard4Label").textContent = "DC NO";
        document.getElementById("modalVendor").textContent = task.vn || "N/A";
        
        document.getElementById("modalCard5Label").textContent = "DC DATE";
        document.getElementById("modalDespatch").textContent = task.dd || "N/A";
        
        document.getElementById("modalCard6Label").textContent = "Step Assigned To";
        document.getElementById("modalDelivery").innerHTML = `<span class="font-bold text-purple-700">${task.doer || task.do || "Assigned Team"}</span>`;
        
        if (card7) card7.classList.add("hidden");
    } else if (isAFS) {
        document.getElementById("modalOrderTitle").textContent = `After Sales: ${key} – ${name}`;
        
        document.getElementById("modalCard1Label").textContent = "Site Name";
        document.getElementById("modalCust").textContent = name;
        
        document.getElementById("modalCard2Label").textContent = "Issue ID / Unique Key";
        document.getElementById("modalSO").textContent = key;
        
        document.getElementById("modalCard3Label").textContent = "Visit Date";
        document.getElementById("modalPO").textContent = task.dd || (task.tab_name.includes("View") ? task.po : "N/A");
        
        document.getElementById("modalCard4Label").textContent = "Category";
        const catVal = (task.po && (task.po.includes("Light") || task.po.includes("Smart"))) ? task.po : (task.vn !== "After Sales" ? task.vn : "General");
        document.getElementById("modalVendor").textContent = catVal;
        
        document.getElementById("modalCard5Label").textContent = "Step Assigned To";
        document.getElementById("modalDespatch").innerHTML = `<span class="font-bold text-purple-700">${task.doer || task.do || "Assigned Team"}</span>`;
        
        document.getElementById("modalCard6Label").textContent = "Sheet Tab";
        document.getElementById("modalDelivery").innerHTML = `<span class="font-bold text-indigo-800">${task.tab_name}</span>`;
        
        if (card7) card7.classList.add("hidden");
    } else {
        document.getElementById("modalOrderTitle").textContent = `${key !== 'N/A' ? key : 'Order'} – ${name}`;
        
        document.getElementById("modalCard1Label").textContent = "Customer / Consumer";
        document.getElementById("modalCust").textContent = name;
        
        document.getElementById("modalCard2Label").textContent = "SO Number";
        document.getElementById("modalSO").textContent = key;
        
        document.getElementById("modalCard3Label").textContent = "PO Number";
        document.getElementById("modalPO").textContent = task.po || "N/A";
        
        document.getElementById("modalCard4Label").textContent = "Vendor Name";
        document.getElementById("modalVendor").textContent = task.vn || "N/A";
        
        document.getElementById("modalCard5Label").textContent = "Despatch Date";
        document.getElementById("modalDespatch").textContent = task.dd || "N/A";
        
        document.getElementById("modalCard6Label").textContent = "Delivery Date";
        document.getElementById("modalDelivery").textContent = task.dl || "N/A";
        
        if (card7) {
            card7.classList.remove("hidden");
            document.getElementById("modalCard7Label").textContent = "Shipment Date";
            document.getElementById("modalShipment").textContent = task.sd || "N/A";
        }
    }

    const stepTbody = document.getElementById("modalStepsTbody");
    stepTbody.innerHTML = "";
    
    // Find all steps for this order/enquiry/return/commission/dc/afs across ALL_TASKS
    const relatedSteps = ALL_TASKS.filter(t => {
        if (isReturn || isDC) {
            return (task.po !== "N/A" && t.po === task.po) || (t.en === task.entity_name);
        }
        if (isComm || isAFS) {
            return (key !== "N/A" && t.so === key) || (t.en === task.entity_name);
        }
        return (key !== "N/A" && t.so === key) || (t.en === task.entity_name);
    });
    relatedSteps.forEach(s => {
        const tr = document.createElement("tr");
        tr.className = "border-b border-slate-100 text-xs";
        let badge = `<span class="px-2 py-0.5 rounded-full font-bold text-[10px] bg-slate-100 text-slate-600">${s.sx}</span>`;
        if (s.cp && s.ot) badge = `<span class="px-2 py-0.5 rounded-full font-bold text-[10px] bg-emerald-100 text-emerald-800">On-Time</span>`;
        else if (s.cp) badge = `<span class="px-2 py-0.5 rounded-full font-bold text-[10px] bg-amber-100 text-amber-800">Delayed</span>`;
        else if (s.sx === "Pending Overdue") badge = `<span class="px-2 py-0.5 rounded-full font-bold text-[10px] bg-rose-100 text-rose-800">Overdue</span>`;
        else badge = `<span class="px-2 py-0.5 rounded-full font-bold text-[10px] bg-blue-100 text-blue-800">Pending</span>`;

        tr.innerHTML = `
            <td class="py-2.5 px-3 font-semibold text-slate-800">${s.st} <span class="text-[10px] text-slate-400 font-normal">(${s.tb})</span></td>
            <td class="py-2.5 px-3 font-bold text-purple-700">${s.do}</td>
            <td class="py-2.5 px-3 text-slate-500 font-mono">${s.pd || '-'}</td>
            <td class="py-2.5 px-3 text-slate-500 font-mono">${s.ad || '-'}</td>
            <td class="py-2.5 px-3 text-center">${badge}</td>
        `;
        stepTbody.appendChild(tr);
    });

    modal.classList.remove("hidden");
    lucide.createIcons();
}

function closeOrderModal() {
    const modal = document.getElementById("orderModal");
    if (modal) modal.classList.add("hidden");
}

document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeOrderModal();
});

function filterTaskTable() {
    taskSearchQuery = document.getElementById("taskSearch").value;
    renderDashboardFromCache();
}

function renderCharts(data) {
    const activeDoers = data.doer_metrics.filter(d=>d.total_assigned>0);
    const labels = activeDoers.map(d=>d.doer);
    const ctx1 = document.getElementById("chartWorkload").getContext("2d");
    if (chartWorkload) chartWorkload.destroy();
    chartWorkload = new Chart(ctx1, {
        type:'bar', data:{ labels, datasets:[
            {label:'Assigned',data:activeDoers.map(d=>d.total_assigned),backgroundColor:'rgba(99,102,241,0.85)',borderRadius:6},
            {label:'Done',data:activeDoers.map(d=>d.total_completed),backgroundColor:'rgba(16,185,129,0.85)',borderRadius:6},
            {label:'On-Time',data:activeDoers.map(d=>d.ontime_completed),backgroundColor:'rgba(6,182,212,0.85)',borderRadius:6}
        ]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'top',labels:{boxWidth:12,font:{weight:'bold',size:11}}}},scales:{y:{beginAtZero:true,grid:{color:'rgba(0,0,0,0.05)'}},x:{grid:{display:false}}}}
    });
    const ctx2 = document.getElementById("chartScore").getContext("2d");
    if (chartScore) chartScore.destroy();
    chartScore = new Chart(ctx2, {
        type:'bar', data:{ labels, datasets:[{label:'On-Time Score %',
            data:activeDoers.map(d=>d.score_percentage),
            backgroundColor:activeDoers.map(d=>d.score_percentage>=85?'rgba(16,185,129,0.85)':d.score_percentage>=50?'rgba(245,158,11,0.85)':'rgba(239,68,68,0.85)'),
            borderRadius:6}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{max:100,beginAtZero:true,grid:{color:'rgba(0,0,0,0.05)'}},x:{grid:{display:false}}}}
    });
}

function switchEnquiryView(view) {
    CURRENT_ENQ_VIEW = view;
    const btnSteps = document.getElementById("btnViewEnqSteps");
    const btnPipe = document.getElementById("btnViewEnqPipeline");
    const secSteps = document.getElementById("standardTaskSection");
    const secPipe = document.getElementById("enquiryPipelineSection");

    if (view === "pipeline") {
        if (btnSteps) btnSteps.className = "px-5 py-2 rounded-lg text-xs font-extrabold transition text-white hover:bg-white/20";
        if (btnPipe) btnPipe.className = "px-5 py-2 rounded-lg text-xs font-extrabold transition bg-white text-indigo-900 shadow";
        if (secSteps) secSteps.classList.add("hidden");
        if (secPipe) {
            secPipe.classList.remove("hidden");
            secPipe.scrollIntoView({ behavior: "smooth", block: "start" });
        }
        renderEnquiryPipeline();
    } else {
        if (btnSteps) btnSteps.className = "px-5 py-2 rounded-lg text-xs font-extrabold transition bg-white text-indigo-900 shadow";
        if (btnPipe) btnPipe.className = "px-5 py-2 rounded-lg text-xs font-extrabold transition text-white hover:bg-white/20";
        if (secSteps) secSteps.classList.remove("hidden");
        if (secPipe) secPipe.classList.add("hidden");
    }
    lucide.createIcons();
}

function renderEnquiryPipeline() {
    const tbody = document.getElementById("enqPipelineTbody");
    const grid = document.getElementById("enqDoerCardsGrid");
    const badge = document.getElementById("enqCountBadge");
    if (!tbody || !ENQUIRY_PIPELINE) return;

    const { startDt, endDt } = parseDateRange();
    const statusFilter = document.getElementById("enqFilterStatus") ? document.getElementById("enqFilterStatus").value : "IN_PROGRESS";
    const searchVal = document.getElementById("enqSearch") ? document.getElementById("enqSearch").value.toLowerCase().trim() : "";
    const doerFilter = document.getElementById("filterDoer") ? document.getElementById("filterDoer").value : "ALL";

    // 1. Calculate Scope Totals for the 6 Cards (Across all statuses)
    let cInProg = 0, aInProg = 0;
    let cOngoing = 0, aOngoing = 0;
    let cWin = 0, aWin = 0;
    let cLoss = 0, aLoss = 0;
    let cClosed = 0, aClosed = 0;
    let cCancel = 0, aCancel = 0;

    let baseList = ENQUIRY_PIPELINE.filter(item => {
        if (startDt || endDt) {
            const dt = parseLocalDate(item.date_raw);
            if (dt) {
                if (startDt && dt < startDt) return false;
                if (endDt && dt > endDt) return false;
            }
        }
        if (doerFilter !== "ALL" && item.doer !== doerFilter) return false;
        return true;
    });

    baseList.forEach(item => {
        const sale = (item.sale_status || "").toLowerCase();
        const stat = (item.overall_status || "").toLowerCase();
        const amt = item.total_quote_amt || 0;

        if (sale.includes("win")) {
            cWin++; aWin += amt;
        } else if (sale.includes("loss")) {
            cLoss++; aLoss += amt;
        } else if (sale.includes("closed")) {
            cClosed++; aClosed += amt;
        } else {
            cInProg++; aInProg += amt;
        }

        if (stat.includes("ongoing")) {
            cOngoing++; aOngoing += amt;
        } else if (stat.includes("cancel")) {
            cCancel++; aCancel += amt;
        } else if (stat.includes("closed") && !sale.includes("closed")) {
            cClosed++; aClosed += amt;
        }
    });

    // Populate the 6 Cards
    const setCard = (cId, aId, count, amt) => {
        const cEl = document.getElementById(cId);
        const aEl = document.getElementById(aId);
        if (cEl) cEl.textContent = count.toLocaleString("en-IN");
        if (aEl) aEl.textContent = `₹${amt.toLocaleString("en-IN")}`;
    };
    setCard("kpiEnqInProgCount", "kpiEnqInProgAmt", cInProg, aInProg);
    setCard("kpiEnqOngoingCount", "kpiEnqOngoingAmt", cOngoing, aOngoing);
    setCard("kpiEnqWinCount", "kpiEnqWinAmt", cWin, aWin);
    setCard("kpiEnqLossCount", "kpiEnqLossAmt", cLoss, aLoss);
    setCard("kpiEnqClosedCount", "kpiEnqClosedAmt", cClosed, aClosed);
    setCard("kpiEnqCancelCount", "kpiEnqCancelAmt", cCancel, aCancel);

    // 2. Filter list for Table & Doer breakdown based on statusFilter & search
    let filtered = baseList.filter(item => {
        const sale = (item.sale_status || "").toLowerCase();
        const stat = (item.overall_status || "").toLowerCase();

        if (statusFilter === "IN_PROGRESS") {
            if (sale.includes("win") || sale.includes("loss") || sale.includes("closed")) return false;
        } else if (statusFilter === "ONGOING") {
            if (!stat.includes("ongoing")) return false;
        } else if (statusFilter === "WIN") {
            if (!sale.includes("win")) return false;
        } else if (statusFilter === "LOSS") {
            if (!sale.includes("loss")) return false;
        } else if (statusFilter === "CLOSED") {
            if (!sale.includes("closed") && !stat.includes("closed")) return false;
        } else if (statusFilter === "CANCEL") {
            if (!stat.includes("cancel")) return false;
        }

        if (searchVal) {
            const match = (item.enq_no && item.enq_no.toLowerCase().includes(searchVal)) ||
                          (item.enq_name && item.enq_name.toLowerCase().includes(searchVal)) ||
                          (item.doer && item.doer.toLowerCase().includes(searchVal)) ||
                          (item.light_quote_no && item.light_quote_no.toLowerCase().includes(searchVal)) ||
                          (item.auto_quote_no && item.auto_quote_no.toLowerCase().includes(searchVal)) ||
                          (item.stuck_step && item.stuck_step.toLowerCase().includes(searchVal));
            if (!match) return false;
        }

        return true;
    });

    if (badge) badge.textContent = `${filtered.length} Enquiries`;

    // 3. Doer Breakdown Map (from baseList or filtered)
    const doerMap = {};
    baseList.forEach(item => {
        const d = item.doer || "Unassigned";
        if (!doerMap[d]) {
            doerMap[d] = {
                doer: d, total: 0, wonAmt: 0, totalAmt: 0, inProg: 0, ongoing: 0, win: 0, loss: 0
            };
        }
        const dm = doerMap[d];
        dm.total++;
        dm.totalAmt += (item.total_quote_amt || 0);

        const sale = (item.sale_status || "").toLowerCase();
        const stat = (item.overall_status || "").toLowerCase();

        if (sale.includes("win")) {
            dm.win++;
            dm.wonAmt += (item.total_quote_amt || 0);
        } else if (sale.includes("loss")) {
            dm.loss++;
        } else if (!sale.includes("closed")) {
            dm.inProg++;
        }

        if (stat.includes("ongoing")) {
            dm.ongoing++;
        }
    });

    // Render Doer Cards (Sorted A to Z)
    if (grid) {
        grid.innerHTML = "";
        const sortedDoers = Object.keys(doerMap).sort();
        if (sortedDoers.length === 0) {
            grid.innerHTML = `<div class="col-span-full py-6 text-center text-slate-400 text-xs font-semibold">No sales team data matching filters</div>`;
        } else {
            sortedDoers.forEach(d => {
                const dm = doerMap[d];
                const card = document.createElement("div");
                card.className = "bg-gradient-to-br from-slate-50 to-white border border-slate-200 rounded-xl p-3.5 shadow-sm hover:shadow-md transition space-y-2";
                card.innerHTML = `
                    <div class="flex items-center justify-between border-b border-slate-100 pb-2">
                        <div class="flex items-center space-x-2">
                            <span class="w-2.5 h-2.5 rounded-full bg-indigo-600"></span>
                            <span class="font-extrabold text-sm text-slate-800">${dm.doer}</span>
                        </div>
                        <span class="text-[11px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                            ${dm.total} Enquiries
                        </span>
                    </div>
                    <div class="flex items-baseline justify-between text-xs pt-0.5">
                        <span class="text-slate-500 font-medium">Won Sales Value</span>
                        <span class="font-extrabold text-emerald-700 font-mono text-sm">₹${dm.wonAmt.toLocaleString("en-IN")}</span>
                    </div>
                    <div class="flex items-baseline justify-between text-xs">
                        <span class="text-slate-500 font-medium">Total Quotes Amount</span>
                        <span class="font-bold text-slate-700 font-mono">₹${dm.totalAmt.toLocaleString("en-IN")}</span>
                    </div>
                    <div class="grid grid-cols-4 gap-1 pt-1.5 text-[10px] text-center font-bold">
                        <div class="bg-amber-50 border border-amber-200 rounded-lg py-1">
                            <div class="text-[9px] text-amber-700 uppercase">In Prog</div>
                            <div class="text-amber-900 font-extrabold">${dm.inProg}</div>
                        </div>
                        <div class="bg-blue-50 border border-blue-200 rounded-lg py-1">
                            <div class="text-[9px] text-blue-700 uppercase">Ongoing</div>
                            <div class="text-blue-900 font-extrabold">${dm.ongoing}</div>
                        </div>
                        <div class="bg-emerald-50 border border-emerald-200 rounded-lg py-1">
                            <div class="text-[9px] text-emerald-700 uppercase">Won</div>
                            <div class="text-emerald-900 font-extrabold">${dm.win}</div>
                        </div>
                        <div class="bg-rose-50 border border-rose-200 rounded-lg py-1">
                            <div class="text-[9px] text-rose-700 uppercase">Loss</div>
                            <div class="text-rose-900 font-extrabold">${dm.loss}</div>
                        </div>
                    </div>
                `;
                grid.appendChild(card);
            });
        }
    }

    // Render Table Body
    tbody.innerHTML = "";
    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="11" class="py-8 text-center text-slate-400 font-semibold text-xs">No enquiries found matching filters</td></tr>`;
        return;
    }

    filtered.forEach(item => {
        const tr = document.createElement("tr");
        tr.className = "hover:bg-amber-50/70 transition cursor-pointer border-b border-slate-100 text-xs group";
        
        // Find matching task for modal
        const mockTask = {
            so: item.enq_no,
            cu: item.enq_name,
            po: "NO",
            vn: item.sale_status,
            dd: item.date,
            dl: item.overall_status,
            fms_name: "2. Order Enquiry FMS",
            tab_name: "MASTERSHEET",
            id: item.enq_no,
            doer: item.doer
        };
        tr.onclick = () => openOrderDetailModal(mockTask);

        const saleL = (item.sale_status || "").toLowerCase();
        let saleBadge = `<span class="px-2 py-0.5 rounded-full font-bold text-[10px] bg-slate-100 text-slate-700">${item.sale_status}</span>`;
        if (saleL.includes("win")) saleBadge = `<span class="px-2 py-0.5 rounded-full font-extrabold text-[10px] bg-emerald-100 text-emerald-800 border border-emerald-300">WIN</span>`;
        else if (saleL.includes("loss")) saleBadge = `<span class="px-2 py-0.5 rounded-full font-extrabold text-[10px] bg-rose-100 text-rose-800 border border-rose-300">LOSS</span>`;
        else if (saleL.includes("closed")) saleBadge = `<span class="px-2 py-0.5 rounded-full font-bold text-[10px] bg-slate-200 text-slate-700">CLOSED</span>`;
        else saleBadge = `<span class="px-2 py-0.5 rounded-full font-bold text-[10px] bg-amber-100 text-amber-800 border border-amber-300">IN PROGRESS</span>`;

        const statL = (item.overall_status || "").toLowerCase();
        let statBadge = `<span class="px-2 py-0.5 rounded-full font-semibold text-[10px] bg-slate-100 text-slate-600">${item.overall_status}</span>`;
        if (statL.includes("ongoing")) statBadge = `<span class="px-2 py-0.5 rounded-full font-bold text-[10px] bg-blue-100 text-blue-800 border border-blue-200 uppercase">ONGOING</span>`;
        else if (statL.includes("closed")) statBadge = `<span class="px-2 py-0.5 rounded-full font-semibold text-[10px] bg-slate-100 text-slate-700 uppercase">CLOSED</span>`;
        else if (statL.includes("cancel")) statBadge = `<span class="px-2 py-0.5 rounded-full font-semibold text-[10px] bg-rose-100 text-rose-700 uppercase">CANCELLED</span>`;

        let stuckHtml = "";
        if (item.stuck_step.includes("All Steps Completed")) {
            stuckHtml = `<span class="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg font-bold text-[11px] bg-emerald-100 text-emerald-800 border border-emerald-300"><i data-lucide="check-circle" class="w-3.5 h-3.5 mr-1"></i>Completed</span>`;
        } else {
            stuckHtml = `<span class="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg font-extrabold text-[11px] bg-rose-50 text-rose-800 border border-rose-200 shadow-sm"><i data-lucide="alert-circle" class="w-3.5 h-3.5 mr-1 text-rose-600 shrink-0"></i><span>${item.stuck_step}</span></span>`;
        }

        const lQuoteAmtStr = item.light_quote_amt > 0 ? `₹${item.light_quote_amt.toLocaleString("en-IN")}` : "-";
        const aQuoteAmtStr = item.auto_quote_amt > 0 ? `₹${item.auto_quote_amt.toLocaleString("en-IN")}` : "-";

        tr.innerHTML = `
            <td class="py-2.5 px-3 font-semibold text-slate-600 whitespace-nowrap">${item.date}</td>
            <td class="py-2.5 px-3"><span class="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 font-mono font-bold text-[11px] border border-indigo-200">${item.enq_no}</span></td>
            <td class="py-2.5 px-3 font-bold text-slate-800 group-hover:text-indigo-600 transition">${item.enq_name}</td>
            <td class="py-2.5 px-3 font-extrabold text-purple-700 whitespace-nowrap">${item.doer}</td>
            <td class="py-2.5 px-3 text-slate-600 font-mono text-[11px]">${item.light_quote_no !== "N/A" ? item.light_quote_no : "-"}</td>
            <td class="py-2.5 px-3 text-right font-mono font-bold text-slate-700 whitespace-nowrap">${lQuoteAmtStr}</td>
            <td class="py-2.5 px-3 text-right font-mono font-bold text-slate-700 whitespace-nowrap">${aQuoteAmtStr}</td>
            <td class="py-2.5 px-3 text-slate-600 font-mono text-[11px]">${item.auto_quote_no !== "N/A" && item.auto_quote_no !== "0" ? item.auto_quote_no : "-"}</td>
            <td class="py-2.5 px-3 text-center whitespace-nowrap">${saleBadge}</td>
            <td class="py-2.5 px-3 text-center whitespace-nowrap">${statBadge}</td>
            <td class="py-2.5 px-3 text-center">${stuckHtml}</td>
        `;
        tbody.appendChild(tr);
    });
    lucide.createIcons();
}

function switchPayDateMode(mode) {
    CURRENT_PAY_DATE_MODE = mode;
    const btnOverdue = document.getElementById("btnPayDateOverdue");
    const btnManual = document.getElementById("btnPayDateManual");
    const notice = document.getElementById("payDateModeNotice");

    if (mode === "manual") {
        if (btnOverdue) btnOverdue.className = "px-4 py-2 rounded-lg text-xs font-extrabold transition text-white hover:bg-white/20";
        if (btnManual) btnManual.className = "px-4 py-2 rounded-lg text-xs font-extrabold transition bg-white text-teal-900 shadow";
        if (notice) notice.textContent = "Date filter matching against Tushar's Manual Planned payment date";
    } else {
        if (btnOverdue) btnOverdue.className = "px-4 py-2 rounded-lg text-xs font-extrabold transition bg-white text-teal-900 shadow";
        if (btnManual) btnManual.className = "px-4 py-2 rounded-lg text-xs font-extrabold transition text-white hover:bg-white/20";
        if (notice) notice.textContent = "Date filter matching against official Overdue Date";
    }
    renderPaymentCrm();
    lucide.createIcons();
}

function renderPaymentCrm() {
    const tbody = document.getElementById("payTableBody");
    const badge = document.getElementById("payCountBadge");
    if (!tbody || !PAYMENT_CRM) return;

    const { startDt, endDt } = parseDateRange();
    const statusFilter = document.getElementById("payFilterStatus") ? document.getElementById("payFilterStatus").value : "PENDING";
    const ageingFilter = document.getElementById("payFilterAgeing") ? document.getElementById("payFilterAgeing").value : "ALL";
    const searchVal = document.getElementById("paySearch") ? document.getElementById("paySearch").value.toLowerCase().trim() : "";

    // 1. Filter base list by selected Date Mode
    let dateFiltered = PAYMENT_CRM.filter(item => {
        if (startDt || endDt) {
            const targetIso = CURRENT_PAY_DATE_MODE === "manual" ? item.manual_iso : item.overdue_iso;
            if (!targetIso) return false;
            const dt = parseLocalDate(targetIso);
            if (dt) {
                if (startDt && dt < startDt) return false;
                if (endDt && dt > endDt) return false;
            }
        }
        return true;
    });

    // 2. Compute 4 Financial KPIs for this Date Period
    let totalExpected = 0;
    let totalPaid = 0;
    let totalOutstanding = 0;
    let pendingAccountsCount = 0;
    let totalPendingDays = 0;

    dateFiltered.forEach(item => {
        totalExpected += (item.effective_amt || 0);
        totalPaid += (item.amt_paid || 0);
        if (item.out_amt > 0) {
            totalOutstanding += item.out_amt;
            pendingAccountsCount++;
            totalPendingDays += (item.days_overdue || 0);
        }
    });

    const avgDays = pendingAccountsCount > 0 ? Math.round(totalPendingDays / pendingAccountsCount) : 0;
    const recoveryRate = totalExpected > 0 ? Math.min(100, Math.round((totalPaid / totalExpected) * 100)) : 0;

    // Set KPI elements
    const kpiExp = document.getElementById("kpiPayExpectedAmt");
    const kpiPaid = document.getElementById("kpiPayPaidAmt");
    const kpiOut = document.getElementById("kpiPayOutstandingAmt");
    const kpiRate = document.getElementById("kpiPayRate");
    const kpiAvgDays = document.getElementById("kpiPayAvgDays");
    const kpiTotalCount = document.getElementById("kpiPayTotalCount");
    const kpiPaidCount = document.getElementById("kpiPayPaidCount");
    const kpiPendingCount = document.getElementById("kpiPayPendingCount");

    if (kpiExp) kpiExp.textContent = `₹${Math.round(totalExpected).toLocaleString("en-IN")}`;
    if (kpiPaid) kpiPaid.textContent = `₹${Math.round(totalPaid).toLocaleString("en-IN")}`;
    if (kpiOut) kpiOut.textContent = `₹${Math.round(totalOutstanding).toLocaleString("en-IN")}`;
    if (kpiRate) kpiRate.textContent = `${recoveryRate}%`;
    if (kpiAvgDays) kpiAvgDays.textContent = `${avgDays} Days`;
    if (kpiTotalCount) kpiTotalCount.textContent = `${dateFiltered.length} Invoices`;
    if (kpiPaidCount) kpiPaidCount.textContent = `${dateFiltered.filter(r => r.amt_paid > 0).length} Paid`;
    if (kpiPendingCount) kpiPendingCount.textContent = `${pendingAccountsCount} Pending`;

    // 3. Filter for Table Display (Status, Ageing, Search)
    let filtered = dateFiltered.filter(item => {
        if (statusFilter === "PENDING" && item.out_amt <= 0) return false;
        if (statusFilter === "PAID" && item.pay_status !== "Fully Paid") return false;
        if (statusFilter === "PARTIAL" && item.pay_status !== "Partially Paid") return false;

        if (ageingFilter !== "ALL" && item.ageing !== ageingFilter) return false;

        if (searchVal) {
            const match = (item.customer_name && item.customer_name.toLowerCase().includes(searchVal)) ||
                          (item.so_no && item.so_no.toLowerCase().includes(searchVal)) ||
                          (item.inv_no && item.inv_no.toLowerCase().includes(searchVal)) ||
                          (item.salesperson && item.salesperson.toLowerCase().includes(searchVal)) ||
                          (item.pay_status && item.pay_status.toLowerCase().includes(searchVal));
            if (!match) return false;
        }
        return true;
    });

    if (badge) badge.textContent = `${filtered.length} Records`;

    // 4. Render Table Rows
    tbody.innerHTML = "";
    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="11" class="py-12 text-center text-slate-400 text-xs font-semibold">No Payment CRM records found matching the selected filters</td></tr>`;
        return;
    }

    filtered.forEach(item => {
        const tr = document.createElement("tr");
        tr.className = "hover:bg-slate-50 transition border-b border-slate-100 text-xs";

        // Ageing badge color
        let ageingBadge = "";
        if (item.days_overdue > 90) {
            ageingBadge = `<span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-100 text-rose-800 border border-rose-300">${item.days_overdue} d (Critical)</span>`;
        } else if (item.days_overdue > 60) {
            ageingBadge = `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">${item.days_overdue} d</span>`;
        } else if (item.days_overdue > 30) {
            ageingBadge = `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-900 border border-blue-200">${item.days_overdue} d</span>`;
        } else {
            ageingBadge = `<span class="px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-50 text-emerald-800 border border-emerald-200">${item.days_overdue} d</span>`;
        }

        // Status badge
        let statusBadge = "";
        if (item.pay_status === "Fully Paid") {
            statusBadge = `<span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300">✅ Fully Paid</span>`;
        } else if (item.pay_status === "Partially Paid") {
            statusBadge = `<span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-800 border border-amber-300">🟡 Partial</span>`;
        } else {
            statusBadge = `<span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-rose-100 text-rose-800 border border-rose-300 animate-pulse">🚨 Pending</span>`;
        }

        const outFormatted = item.out_amt > 0 
            ? `<span class="font-mono font-black text-rose-700">₹${Math.round(item.out_amt).toLocaleString("en-IN")}</span>`
            : `<span class="font-mono text-emerald-700 font-bold">₹0</span>`;

        tr.className = "hover:bg-amber-50/60 cursor-pointer transition border-b border-slate-100 text-xs";
        tr.onclick = () => openPaymentDetails(item.id);

        tr.innerHTML = `
            <td class="py-3 px-3 font-extrabold text-slate-900 group-hover:text-indigo-600">${item.customer_name}</td>
            <td class="py-3 px-3 font-mono font-bold text-slate-700">${item.so_no}</td>
            <td class="py-3 px-3">
                <div class="font-mono font-semibold text-slate-800">${item.inv_no}</div>
                <div class="text-[10px] text-slate-400">${item.inv_dt}</div>
            </td>
            <td class="py-3 px-3 font-medium text-slate-600">${item.salesperson}</td>
            <td class="py-3 px-3 text-right font-mono font-bold text-slate-700">₹${Math.round(item.effective_amt).toLocaleString("en-IN")}</td>
            <td class="py-3 px-3 text-right font-mono font-bold text-emerald-700">₹${Math.round(item.amt_paid).toLocaleString("en-IN")}</td>
            <td class="py-3 px-3 text-right bg-rose-50/50">${outFormatted}</td>
            <td class="py-3 px-3 font-mono text-slate-600">${item.overdue_dt}</td>
            <td class="py-3 px-3 font-mono font-bold text-amber-900 bg-amber-50/70 border-x border-amber-200/50">${item.manual_dt}</td>
            <td class="py-3 px-3 font-mono text-slate-600">${item.next_manual_dt !== "N/A" ? item.next_manual_dt : "-"}</td>
            <td class="py-3 px-3 text-center">${ageingBadge}</td>
            <td class="py-3 px-3 text-center">${statusBadge}</td>
        `;
        tbody.appendChild(tr);
    });
    lucide.createIcons();
}

function openPaymentDetails(payId) {
    const item = PAYMENT_CRM.find(p => p.id === payId);
    if (!item) return;

    const modal = document.getElementById("orderModal");
    const title = document.getElementById("modalOrderTitle");
    const grid = document.getElementById("modalOrderGrid");
    const tbody = document.getElementById("modalStepsTbody");

    if (title) title.textContent = `Payment CRM: ${item.customer_name}`;

    if (grid) {
        grid.innerHTML = `
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Customer Name</span>
                <span class="font-extrabold text-sm text-slate-900">${item.customer_name}</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">SO Reference Number</span>
                <span class="font-mono font-bold text-slate-800">${item.so_no}</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">SO Amount</span>
                <span class="font-mono font-bold text-slate-800">₹${item.so_amt.toLocaleString("en-IN")}</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Invoice Number & Date</span>
                <span class="font-mono font-bold text-slate-800">${item.inv_no} (${item.inv_dt})</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Invoice Amount</span>
                <span class="font-mono font-bold text-slate-800">₹${item.inv_amt.toLocaleString("en-IN")}</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Delivery Challan</span>
                <span class="font-mono text-slate-700">${item.dc_no} (${item.dc_dt})</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Credit Period</span>
                <span class="font-semibold text-slate-700">${item.credit_period}</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Salesperson</span>
                <span class="font-semibold text-purple-700">${item.salesperson}</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Outstanding Amount</span>
                <span class="font-mono font-black text-rose-700 text-base">₹${Math.round(item.out_amt).toLocaleString("en-IN")}</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Overdue Date & Days</span>
                <span class="font-mono text-slate-800">${item.overdue_dt} (${item.days_overdue} days overdue)</span>
            </div>
            <div class="col-span-full bg-amber-50 border border-amber-300 rounded-xl p-3 shadow-inner">
                <span class="text-amber-800 block text-xs font-black uppercase tracking-wider">Manual Planned payment date (Can be EDITED tushar can fill)</span>
                <span class="font-mono font-black text-base text-amber-950">${item.manual_dt}</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Actual Date of Payment (1st)</span>
                <span class="font-mono font-bold text-emerald-700">${item.actual_dt}</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Amount Paid (1st)</span>
                <span class="font-mono font-bold text-emerald-700">₹${item.amt_paid_1.toLocaleString("en-IN")}</span>
            </div>
            <div class="col-span-full bg-blue-50 border border-blue-200 rounded-xl p-3 shadow-inner">
                <span class="text-blue-800 block text-xs font-black uppercase tracking-wider">Manual Planned next payment date (only tushar can fill)</span>
                <span class="font-mono font-black text-base text-blue-950">${item.next_manual_dt}</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Actual Date of Payment (2nd)</span>
                <span class="font-mono font-bold text-emerald-700">${item.actual_dt_2}</span>
            </div>
            <div>
                <span class="text-slate-400 block text-[10px] font-bold uppercase">Amount Paid (2nd)</span>
                <span class="font-mono font-bold text-emerald-700">₹${item.amt_paid_2.toLocaleString("en-IN")}</span>
            </div>
        `;
    }

    if (tbody) {
        tbody.innerHTML = `
            <tr class="bg-emerald-50/50">
                <td class="py-2.5 px-3 font-bold text-slate-800">Total Paid Amount</td>
                <td class="py-2.5 px-3 font-mono font-extrabold text-emerald-700">CRM</td>
                <td class="py-2.5 px-3 font-mono text-slate-600">${item.manual_dt}</td>
                <td class="py-2.5 px-3 font-mono text-slate-600">${item.actual_dt}</td>
                <td class="py-2.5 px-3 text-center font-bold text-emerald-700">₹${item.amt_paid.toLocaleString("en-IN")}</td>
            </tr>
            <tr class="${item.out_amt > 0 ? 'bg-rose-50/50' : ''}">
                <td class="py-2.5 px-3 font-bold text-slate-800">Remaining Balance</td>
                <td class="py-2.5 px-3 font-mono font-extrabold text-slate-700">CRM</td>
                <td class="py-2.5 px-3 font-mono text-slate-600">${item.overdue_dt}</td>
                <td class="py-2.5 px-3 font-mono text-slate-600">-</td>
                <td class="py-2.5 px-3 text-center font-black text-rose-700">₹${item.out_amt.toLocaleString("en-IN")}</td>
            </tr>
        `;
    }

    if (modal) modal.classList.remove("hidden");
    lucide.createIcons();
}

function printSpecificSection(sectionId) {
    document.body.classList.add("print-only-mode");
    const sec = document.getElementById(sectionId);
    if (sec) sec.classList.add("print-target-section");
    window.print();
    setTimeout(() => {
        document.body.classList.remove("print-only-mode");
        if (sec) sec.classList.remove("print-target-section");
    }, 1500);
}

