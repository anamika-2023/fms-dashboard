let reportData = null;
let currentPreset = "ALL_TIME";
let chartWorkload = null;
let chartScore = null;

document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons();
    initMetadata();
    loadReport();
});

// ─────────────────────────────────────────────
// Metadata & Dropdown Init
// ─────────────────────────────────────────────
async function initMetadata() {
    try {
        const resp = await fetch("/api/meta");
        const data = await resp.json();

        // Populate FMS Dropdown
        const fmsSelect = document.getElementById("filterFms");
        fmsSelect.innerHTML = '<option value="ALL">All 8 FMS (Combined Report)</option>';
        data.fms_list.forEach(item => {
            const opt = document.createElement("option");
            opt.value = item.id;
            opt.textContent = item.name;
            fmsSelect.appendChild(opt);
        });

        // Populate Doer Dropdown
        const doerSelect = document.getElementById("filterDoer");
        doerSelect.innerHTML = '<option value="ALL">All Doers</option>';
        data.doers.forEach(d => {
            if (d && d !== "UNASSIGNED") {
                const opt = document.createElement("option");
                opt.value = d;
                opt.textContent = d;
                doerSelect.appendChild(opt);
            }
        });
    } catch (e) {
        console.error("Error loading metadata:", e);
    }
}

// ─────────────────────────────────────────────
// Preset & Date Range Controls
// ─────────────────────────────────────────────
function applyPreset(preset) {
    currentPreset = preset;

    // Reset all preset buttons to inactive
    const presetIds = ["btnPresetToday", "btnPresetYesterday", "btnPresetThisWeek", "btnPresetLastWeek", "btnPresetAllTime"];
    presetIds.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.className = "preset-btn-inactive px-3.5 py-1.5 rounded-xl font-bold transition text-xs border";
        }
    });

    // Highlight active preset button
    const map = {
        "TODAY": "btnPresetToday",
        "YESTERDAY": "btnPresetYesterday",
        "THIS_WEEK": "btnPresetThisWeek",
        "LAST_WEEK": "btnPresetLastWeek",
        "ALL_TIME": "btnPresetAllTime"
    };
    const activeBtn = document.getElementById(map[preset]);
    if (activeBtn) {
        activeBtn.className = "preset-btn-active px-3.5 py-1.5 rounded-xl font-bold transition text-xs border shadow-sm";
    }

    const startInput = document.getElementById("startDate");
    const endInput = document.getElementById("endDate");

    const today = new Date();
    const formatDate = (d) => {
        const yyyy = d.getFullYear();
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        return `${yyyy}-${mm}-${dd}`;
    };

    if (preset === "TODAY") {
        startInput.value = formatDate(today);
        endInput.value = formatDate(today);
        document.getElementById("activeFilterLabel").innerHTML = `Currently showing: <strong>Today's Report (${startInput.value})</strong>`;
    } else if (preset === "YESTERDAY") {
        const yest = new Date(today);
        yest.setDate(yest.getDate() - 1);
        startInput.value = formatDate(yest);
        endInput.value = formatDate(yest);
        document.getElementById("activeFilterLabel").innerHTML = `Currently showing: <strong>Yesterday's Report (${startInput.value})</strong>`;
    } else if (preset === "THIS_WEEK") {
        const mon = new Date(today);
        const day = mon.getDay();
        const diff = mon.getDate() - day + (day === 0 ? -6 : 1);
        mon.setDate(diff);
        startInput.value = formatDate(mon);
        endInput.value = formatDate(today);
        document.getElementById("activeFilterLabel").innerHTML = `Currently showing: <strong>This Week's Report (${startInput.value} to ${endInput.value})</strong>`;
    } else if (preset === "LAST_WEEK") {
        const mon = new Date(today);
        const day = mon.getDay();
        const diff = mon.getDate() - day + (day === 0 ? -6 : 1);
        mon.setDate(diff - 7);
        const sun = new Date(mon);
        sun.setDate(mon.getDate() + 6);
        startInput.value = formatDate(mon);
        endInput.value = formatDate(sun);
        document.getElementById("activeFilterLabel").innerHTML = `Currently showing: <strong>Last Week's Report (${startInput.value} to ${endInput.value})</strong>`;
    } else if (preset === "ALL_TIME") {
        startInput.value = "";
        endInput.value = "";
        document.getElementById("activeFilterLabel").innerHTML = `Currently showing: <strong>All Time Data</strong>`;
    }

    loadReport();
}

function onCustomDateInput() {
    currentPreset = "CUSTOM";
    const presetIds = ["btnPresetToday", "btnPresetYesterday", "btnPresetThisWeek", "btnPresetLastWeek", "btnPresetAllTime"];
    presetIds.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.className = "preset-btn-inactive px-3.5 py-1.5 rounded-xl font-bold transition text-xs border";
        }
    });

    const start = document.getElementById("startDate").value;
    const end = document.getElementById("endDate").value;
    if (start && end) {
        document.getElementById("activeFilterLabel").innerHTML = `Currently showing: <strong>Custom Range (${start} to ${end})</strong>`;
    }
}

function submitFilter() {
    const start = document.getElementById("startDate").value;
    const end = document.getElementById("endDate").value;
    if (start || end) {
        currentPreset = "CUSTOM";
    }
    loadReport();
}

// ─────────────────────────────────────────────
// Main Report Fetch & Render
// ─────────────────────────────────────────────
async function loadReport(forceRefresh = false) {
    const fms = document.getElementById("filterFms").value;
    const startDate = document.getElementById("startDate").value;
    const endDate = document.getElementById("endDate").value;
    const doer = document.getElementById("filterDoer").value;
    const status = document.getElementById("filterStatus").value;

    let datePresetParam = currentPreset;
    let url = `/api/report?fms=${fms}&date_preset=${datePresetParam}&doer=${encodeURIComponent(doer)}&status=${status}&refresh=${forceRefresh}`;
    if (startDate && endDate) {
        url += `&start_date=${startDate}&end_date=${endDate}`;
    }

    // Animate submit button
    const btnSubmit = document.getElementById("btnSubmitFilter");
    if (btnSubmit) {
        btnSubmit.innerHTML = `<i data-lucide="loader-2" class="w-4 h-4 animate-spin"></i><span>Loading...</span>`;
        lucide.createIcons();
    }

    try {
        const resp = await fetch(url);
        reportData = await resp.json();
        renderDashboard(reportData);
    } catch (e) {
        console.error("Error loading report:", e);
    } finally {
        if (btnSubmit) {
            btnSubmit.innerHTML = `<i data-lucide="search" class="w-4 h-4"></i><span>View Report</span>`;
            lucide.createIcons();
        }
    }
}

async function refreshData() {
    const btn = document.getElementById("btnRefresh");
    const icon = document.getElementById("refreshIcon");
    icon.classList.add("animate-spin");
    btn.disabled = true;

    try {
        await loadReport(true);
        document.getElementById("syncStatus").innerHTML = `
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse mr-2"></span>
            Synced Just Now
        `;
    } catch (e) {
        console.error("Refresh error:", e);
    } finally {
        icon.classList.remove("animate-spin");
        btn.disabled = false;
    }
}

function renderDashboard(data) {
    // 5 KPI Summary Cards
    document.getElementById("kpiAssigned").textContent = data.total_assigned.toLocaleString();
    document.getElementById("kpiCompleted").textContent = data.total_completed.toLocaleString();
    const compRate = data.total_assigned ? ((data.total_completed / data.total_assigned) * 100).toFixed(1) : 0;
    document.getElementById("kpiCompletedSub").textContent = `${compRate}% completion rate`;

    document.getElementById("kpiOntime").textContent = data.ontime_completed.toLocaleString();
    document.getElementById("kpiOntimeSub").textContent = `${data.delayed_completed.toLocaleString()} delayed completions`;

    document.getElementById("kpiScore").textContent = `${data.overall_score_percentage}%`;

    document.getElementById("kpiPending").textContent = data.total_pending.toLocaleString();
    document.getElementById("kpiOverdueSub").textContent = `${data.pending_overdue.toLocaleString()} pending overdue tasks`;

    // Render Doer Leaderboard Table
    const tbody = document.getElementById("doerTableBody");
    tbody.innerHTML = "";
    data.doer_metrics.forEach(d => {
        const tr = document.createElement("tr");
        tr.className = "hover:bg-indigo-50/70 transition cursor-pointer border-b border-slate-100";
        tr.onclick = () => filterByDoer(d.doer);

        // Work Done Score % — high % = bad (pending deficit). Green < 20%, Yellow 20-50%, Red >= 50%
        const wds = d.work_done_score;
        let wdsBadge = `<span class="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold text-xs">${wds}%</span>`;
        if (wds >= 50) wdsBadge = `<span class="bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full font-bold text-xs">${wds}%</span>`;
        else if (wds >= 20) wdsBadge = `<span class="bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-bold text-xs">${wds}%</span>`;
        if (d.total_assigned === 0) wdsBadge = `<span class="bg-slate-100 text-slate-400 px-2 py-0.5 rounded-full text-xs">—</span>`;

        // On-Time Delay Score % — 0% = BEST (0% delay), > 0% = Delay %
        const otScore = d.ontime_delay_score;
        let otBadge = `<span class="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold text-xs">${otScore}%</span>`;
        if (otScore >= 50) otBadge = `<span class="bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full font-bold text-xs">${otScore}%</span>`;
        else if (otScore > 0) otBadge = `<span class="bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-bold text-xs">${otScore}%</span>`;
        if (d.total_completed === 0) otBadge = `<span class="bg-slate-100 text-slate-400 px-2 py-0.5 rounded-full text-xs">—</span>`;

        tr.innerHTML = `
            <td class="py-3 px-3.5 font-bold text-slate-800 flex items-center space-x-2">
                <span class="w-2 h-2 rounded-full ${d.total_assigned > 0 ? 'bg-emerald-500' : 'bg-slate-300'}"></span>
                <span>${d.doer}</span>
            </td>
            <td class="py-3 px-3.5 text-center font-semibold text-slate-700">${d.total_assigned}</td>
            <td class="py-3 px-3.5 text-center font-semibold text-emerald-600">${d.total_completed}</td>
            <td class="py-3 px-3.5 text-center font-semibold text-cyan-600">${d.ontime_completed}</td>
            <td class="py-3 px-3.5 text-center font-semibold ${d.total_pending > 0 ? 'text-rose-500 font-bold' : 'text-slate-400'}">${d.total_pending}</td>
            <td class="py-3 px-3.5 text-center font-bold">${wdsBadge}</td>
            <td class="py-3 px-3.5 text-center font-bold">${otBadge}</td>
            <td class="py-3 px-3.5 text-center font-bold ${d.pending_overdue > 0 ? 'text-rose-700' : 'text-slate-400'}">${d.pending_overdue}</td>
        `;
        tbody.appendChild(tr);
    });

    // Render FMS Sheet Summary
    const fmsBody = document.getElementById("fmsTableBody");
    fmsBody.innerHTML = "";
    data.fms_summaries.forEach(f => {
        if (f.total_tasks > 0) {
            const tr = document.createElement("tr");
            tr.className = "hover:bg-purple-50/70 transition border-b border-slate-100";
            tr.innerHTML = `
                <td class="py-2.5 px-3 font-semibold text-slate-800 text-xs truncate max-w-[140px]" title="${f.fms_name}">${f.fms_name}</td>
                <td class="py-2.5 px-3 text-center text-xs font-bold text-slate-700">${f.total_tasks}</td>
                <td class="py-2.5 px-3 text-center text-xs font-semibold text-emerald-600">${f.completed_tasks}</td>
                <td class="py-2.5 px-3 text-center text-xs font-bold text-purple-700">${f.overall_score}%</td>
            `;
            fmsBody.appendChild(tr);
        }
    });

    // Render Task Table
    renderTaskTable(data.task_items);

    // Render Visual Analytics Charts
    renderCharts(data);
}

function filterByDoer(doerName) {
    document.getElementById("filterDoer").value = doerName;
    loadReport().then(() => {
        // Auto scroll to task table so user sees the steps
        const taskSection = document.getElementById("taskTableSection");
        if (taskSection) taskSection.scrollIntoView({ behavior: "smooth", block: "start" });
    });
}

function renderTaskTable(tasks) {
    const tbody = document.getElementById("taskTableBody");
    tbody.innerHTML = "";
    document.getElementById("taskCountBadge").textContent = `${tasks.length} Tasks`;

    tasks.slice(0, 200).forEach(t => {
        const tr = document.createElement("tr");
        tr.className = "hover:bg-slate-50 transition border-b border-slate-100 text-xs";

        let stBadge = `<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-slate-100 text-slate-700">${t.status}</span>`;
        if (t.status === "Completed On-Time") {
            stBadge = `<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-emerald-100 text-emerald-800">Completed On-Time</span>`;
        } else if (t.status === "Completed Delayed") {
            stBadge = `<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-amber-100 text-amber-800">Completed Delayed</span>`;
        } else if (t.status === "Advance Done") {
            stBadge = `<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-purple-100 text-purple-800">Advance Done (Extra)</span>`;
        } else if (t.status === "Pending Overdue" || t.status.includes("Pending Overdue")) {
            if (t.status.includes("Past Backlog")) {
                stBadge = `<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-red-100 text-red-900 border border-red-300">Overdue (Past Backlog)</span>`;
            } else {
                stBadge = `<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-rose-100 text-rose-800">Pending Overdue</span>`;
            }
        } else if (t.status === "Pending On-Track") {
            stBadge = `<span class="px-2.5 py-1 rounded-full font-bold text-[11px] bg-blue-100 text-blue-800">Pending On-Track</span>`;
        }

        let delayText = "-";
        if (t.delay_hours > 0) delayText = `<span class="text-amber-700 font-bold">${t.delay_hours} hrs delayed</span>`;
        if (t.overdue_hours > 0) delayText = `<span class="text-rose-700 font-bold">${t.overdue_hours} hrs overdue</span>`;

        tr.innerHTML = `
            <td class="py-2.5 px-3">
                <span class="font-bold text-indigo-700">${t.fms_name}</span>
                <span class="block text-[10px] text-slate-400 font-medium">${t.tab_name}</span>
            </td>
            <td class="py-2.5 px-3 font-semibold text-slate-800 max-w-[200px] truncate" title="${t.entity_name}">${t.entity_name}</td>
            <td class="py-2.5 px-3 font-medium text-slate-700 max-w-[220px] truncate" title="${t.step_name}">${t.step_name}</td>
            <td class="py-2.5 px-3 font-bold text-purple-700">${t.doer}</td>
            <td class="py-2.5 px-3 text-slate-500 font-mono">${t.planned_date || '-'}</td>
            <td class="py-2.5 px-3 text-slate-500 font-mono">${t.actual_date || '-'}</td>
            <td class="py-2.5 px-3 text-center">${stBadge}</td>
            <td class="py-2.5 px-3 text-center font-medium">${delayText}</td>
        `;
        tbody.appendChild(tr);
    });
}

function filterTaskTable() {
    const q = document.getElementById("taskSearch").value.toLowerCase();
    if (!reportData || !reportData.task_items) return;
    const filtered = reportData.task_items.filter(t => 
        (t.entity_name && t.entity_name.toLowerCase().includes(q)) ||
        (t.step_name && t.step_name.toLowerCase().includes(q)) ||
        (t.doer && t.doer.toLowerCase().includes(q)) ||
        (t.fms_name && t.fms_name.toLowerCase().includes(q))
    );
    renderTaskTable(filtered);
}

function renderCharts(data) {
    const activeDoers = data.doer_metrics.filter(d => d.total_assigned > 0);
    const labels = activeDoers.map(d => d.doer);

    // Chart 1: Workload
    const ctx1 = document.getElementById("chartWorkload").getContext("2d");
    if (chartWorkload) chartWorkload.destroy();
    chartWorkload = new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                { label: 'Assigned', data: activeDoers.map(d => d.total_assigned), backgroundColor: 'rgba(99, 102, 241, 0.85)', borderRadius: 6 },
                { label: 'Done', data: activeDoers.map(d => d.total_completed), backgroundColor: 'rgba(16, 185, 129, 0.85)', borderRadius: 6 },
                { label: 'On-Time', data: activeDoers.map(d => d.ontime_completed), backgroundColor: 'rgba(6, 182, 212, 0.85)', borderRadius: 6 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'top', labels: { boxWidth: 12, font: { weight: 'bold', size: 11 } } } },
            scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } }, x: { grid: { display: false } } }
        }
    });

    // Chart 2: Score %
    const ctx2 = document.getElementById("chartScore").getContext("2d");
    if (chartScore) chartScore.destroy();
    chartScore = new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'On-Time Score %',
                data: activeDoers.map(d => d.score_percentage),
                backgroundColor: activeDoers.map(d => d.score_percentage >= 85 ? 'rgba(16, 185, 129, 0.85)' : d.score_percentage >= 50 ? 'rgba(245, 158, 11, 0.85)' : 'rgba(239, 68, 68, 0.85)'),
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { max: 100, beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } }, x: { grid: { display: false } } }
        }
    });
}
