from fastapi import FastAPI, Request, Query
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import os
from dataclasses import asdict
from typing import Optional

from fms_parser import generate_report, fetch_and_parse_all_sheets, FMS_CONFIGS

app = FastAPI(title="FMS Analytics & Reporting System", version="1.0.0")

# Mounting static files
base_dir = os.path.dirname(os.path.abspath(__file__))
app.mount("/static", StaticFiles(directory=os.path.join(base_dir, "static")), name="static")

@app.on_event("startup")
async def startup_preload():
    """Pre-load all Google Sheets data when server starts so first visitor doesn't wait."""
    import asyncio, threading
    def _load():
        try:
            fetch_and_parse_all_sheets(force_refresh=True)
            print("[OK] Data pre-loaded successfully on startup!")
        except Exception as e:
            print(f"[WARN] Startup preload warning: {e}")
    thread = threading.Thread(target=_load, daemon=True)
    thread.start()

@app.get("/", response_class=FileResponse)
async def read_root():
    return FileResponse(os.path.join(base_dir, "templates", "index.html"))

@app.get("/api/report")
async def get_report(
    fms: str = Query("ALL", description="FMS Sheet ID (e.g. ALL or fms_1 to fms_8)"),
    date_preset: str = Query("ALL_TIME", description="Date preset (TODAY, YESTERDAY, THIS_WEEK, LAST_WEEK, CUSTOM, ALL_TIME)"),
    start_date: Optional[str] = Query(None, description="Custom start date YYYY-MM-DD"),
    end_date: Optional[str] = Query(None, description="Custom end date YYYY-MM-DD"),
    doer: str = Query("ALL", description="Filter by Doer Name"),
    status: str = Query("ALL", description="Filter by Status"),
    refresh: bool = Query(False, description="Force refresh from Google Sheets")
):
    try:
        report = generate_report(
            fms_filter=fms,
            date_preset=date_preset,
            custom_start=start_date,
            custom_end=end_date,
            doer_filter=doer,
            status_filter=status,
            force_refresh=refresh
        )
        return JSONResponse(content=asdict(report))
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})

@app.get("/api/meta")
async def get_metadata():
    tasks = fetch_and_parse_all_sheets(force_refresh=False)
    doers = sorted(list(set(t.doer for t in tasks if t.doer)))
    fms_list = [{"id": cfg["id"], "name": cfg["name"]} for cfg in FMS_CONFIGS]
    return JSONResponse(content={
        "fms_list": fms_list,
        "doers": doers,
        "total_parsed_tasks": len(tasks)
    })

@app.get("/api/refresh")
async def refresh_data():
    tasks = fetch_and_parse_all_sheets(force_refresh=True)
    return JSONResponse(content={
        "status": "success",
        "message": f"Successfully re-synced {len(tasks)} tasks from 8 Google Sheets!"
    })

if __name__ == "__main__":
    import uvicorn, os
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("app:app", host="0.0.0.0", port=port, reload=False)
