import csv
import io
import re
import urllib.request
import urllib.parse
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
import concurrent.futures

from models import TaskItem, DoerMetric, FMSReportSummary, AggregatedReport

# ─────────────────────────────────────────────
# 9 FMS Configurations
# ─────────────────────────────────────────────
FMS_CONFIGS = [
    {"id": "fms_1", "name": "1. Order to Dispatch FMS",  "sheet_id": "10TbhEQXJBVqGu0jesUioaCuzxwPzu84hM98bVuL1qL0", "tabs": ["SOTOPO","GeneratePO","PaymentCRM","Delivery","invoiceandpayment"]},
    {"id": "fms_2", "name": "2. Order Enquiry FMS",       "sheet_id": "181kyeqN7Y2cWkHjNiRMwqeBGnY-WxNBbDyadhsxuOWU", "tabs": ["MASTERSHEET"]},
    {"id": "fms_3", "name": "3. Delegation FMS",          "sheet_id": "13DOrgKjhDRCRaEk8n4TSDZLGTZFDeVl0SeS7z3MMwF0", "tabs": ["Master"]},
    {"id": "fms_4", "name": "4. Checklist FMS",           "sheet_id": "1j5RPy6PgfZqsJc5rtrvxnY5w5z18aOfaFsjEObf-uE0", "tabs": ["Master"]},
    {"id": "fms_5", "name": "5. Return FMS",              "sheet_id": "1P-q37fLC8BXMxG89MaNDmm3FV5UIpPsC9Z_dztUeouY", "tabs": ["RETURNFMS"]},
    {"id": "fms_6", "name": "6. After Sales FMS",         "sheet_id": "1r9FvYToT8K22iT_3YsrOWpxqCblfVOmYKt1X8GQIhLo", "tabs": ["Dashboard", " FMS For View only"]},
    {"id": "fms_7", "name": "7. Delivery Challan FMS",    "sheet_id": "1fTs8v35jM1nqhiC7QEngP1vgCPt2yMb0L0PPJWWeg8k", "tabs": ["Fms"]},
    {"id": "fms_8", "name": "8. Commission FMS",          "sheet_id": "1DgNrXuzCsasF0VdWionTuW2f1HhzjWPzqjtNrW4dcZo", "tabs": ["Fms"]},
    {"id": "fms_9", "name": "9. Payment CRM",            "sheet_id": "1hJABRsV9GmR3pUUOAYTuvA-9f8ieQApzN_BFNmeo_5U", "tabs": ["Payment CRM"]},
]

# Real team members confirmed by user
PRIMARY_DOERS = ["CRM", "PRAKASH", "AMOL", "LALIT", "MIS", "PC",
                 "SUBHOJIT", "SOUVIK", "TUSHAR", "PREM",
                 "SUSMITA", "HARSH", "RIYA", "SAHA", "JAYANTA", "KARMAKAR", "MEET", "SAJAL", "PATRO DA", "ROHIT"]


DATA_CACHE: Dict = {"timestamp": None, "tasks": [], "enquiry_pipeline": [], "payment_crm": []}


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────
def cs(val: Any) -> str:
    """Clean string."""
    v = str(val).strip() if val is not None else ""
    return "" if v.upper() in {"#N/A","#REF!","#VALUE!","N/A","NA"} else v

def normalize_doer(raw: str) -> str:
    name = cs(raw).upper()
    if not name or name in {"NA","N/A","-","NONE","0","#N/A","#REF!","UNASSIGNED",""}:
        return "UNASSIGNED"
    MAP = {
        # CRM
        "CRM":"CRM", "SALES/CRM":"CRM", "SALES":"CRM",
        "HINDLIGHTINGCRM@GMAIL.COM":"CRM",
        # PRAKASH
        "PRAKASH":"PRAKASH", "PRAKASH DAS":"PRAKASH",
        # Real doers from master SOD
        "PC":"PC",                                    # Purchase/Courier controller
        "MIS":"MIS",                                  # Management Info System
        "LALIT":"LALIT",                              # Lalit
        "AMOL":"AMOL", "AMAL":"AMOL",
        "SUBHOJIT":"SUBHOJIT", "SUBHOJIT RIYA":"SUBHOJIT",
        "SOUVIK":"SOUVIK", "TUSHAR":"TUSHAR", "PREM":"PREM",
        "SUSMITA":"SUSMITA", "HARSH":"HARSH",
        "RIYA":"RIYA", "SAHA":"SAHA", "AMAL SAHA":"SAHA", "AMOL SAHA":"SAHA",
        "JAYANTA":"JAYANTA", "JAYANTAR":"JAYANTA",
        "KARMAKAR":"KARMAKAR", "MEET":"MEET", "SAJAL":"SAJAL",
        "PATRO DA":"PATRO DA", "PATRO":"PATRO DA",
        "ROHIT PRASAD":"ROHIT", "ROHIT":"ROHIT",
    }
    return MAP.get(name, cs(raw).title())

def parse_date(s: Any) -> Optional[datetime]:
    if not s:
        return None
    v = cs(s)
    if not v or v.upper() in {"NA","N/A","-","#REF!","#N/A","NONE","0","NOT REQUIRED","00/00/0000","#VALUE!"}:
        return None
    v = re.sub(r'([0-9]{1,2}:[0-9]{2})(AM|PM)', r'\1 \2', v, flags=re.IGNORECASE)
    FMT = ["%d/%m/%Y %I:%M %p","%d/%m/%Y %H:%M:%S","%d/%m/%Y %H:%M",
           "%d/%m/%Y","%m/%d/%Y %H:%M:%S","%m/%d/%Y %H:%M","%m/%d/%Y",
           "%Y-%m-%d %H:%M:%S","%Y-%m-%d %H:%M","%Y-%m-%d","%d-%m-%Y"]
    for f in FMT:
        try:
            return datetime.strptime(v, f)
        except ValueError:
            pass
    try:
        from dateutil import parser as dp
        return dp.parse(v, dayfirst=True)
    except Exception:
        return None

def fetch_csv(sheet_id: str, tab: str) -> List[List[str]]:
    url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/gviz/tq?tqx=out:csv&sheet={urllib.parse.quote(tab)}"
    import time
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
            with urllib.request.urlopen(req, timeout=35) as r:
                return list(csv.reader(io.StringIO(r.read().decode('utf-8','ignore'))))
        except Exception as e:
            if attempt < 2:
                time.sleep(1.5)
            else:
                print(f"[FETCH ERROR] {sheet_id}/{tab}: {e}")
                return []
    return []

def make_task(tid, fid, fname, tab, row_no, entity, step, doer, planned, actual, raw_st,
              so_no="N/A", po_no="N/A", customer_name="N/A", vendor_name="N/A",
              despatch_date="N/A", delivery_date="N/A", shipment_date="N/A") -> Optional[TaskItem]:
    """Create a TaskItem according to strict user rules:
    - Task is completed ONLY when actual date is present.
    - If actual date is blank/None, task is PENDING.
    - On-Time ONLY when actual <= planned deadline.
    """
    if planned is None and actual is None:
        return None

    now = datetime.now()
    completed = (actual is not None)
    
    if completed:
        if planned and actual:
            if planned.hour == 0 and planned.minute == 0:
                effective_deadline = planned.replace(hour=23, minute=59, second=59)
            else:
                effective_deadline = planned

            on_time = (actual <= effective_deadline)
            status = "Completed On-Time" if on_time else "Completed Delayed"
            delay = max(0.0, round((actual - effective_deadline).total_seconds()/3600, 1)) if not on_time else 0.0
        else:
            on_time = True
            status = "Completed On-Time"
            delay = 0.0
        overdue = 0.0
    else:
        on_time = False
        delay = 0.0
        if planned and planned < now:
            status = "Pending Overdue"
            overdue = round((now - planned).total_seconds()/3600, 1)
        else:
            status = "Pending On-Track"
            overdue = 0.0

    norm_doer = normalize_doer(doer)
    if not norm_doer or norm_doer == "UNASSIGNED" or norm_doer in {"NA", "N/A", "NONE", "0"}:
        return None

    return TaskItem(
        id=tid, fms_id=fid, fms_name=fname, tab_name=tab, row_index=row_no,
        entity_name=entity, step_name=step, doer=norm_doer,
        planned_date=planned.strftime("%Y-%m-%d %H:%M") if planned else None,
        actual_date=actual.strftime("%Y-%m-%d %H:%M") if actual else None,
        status=status, is_completed=completed, is_ontime=on_time,
        delay_hours=delay, overdue_hours=overdue, remarks=raw_st,
        so_no=so_no, po_no=po_no, customer_name=customer_name, vendor_name=vendor_name,
        despatch_date=despatch_date, delivery_date=delivery_date, shipment_date=shipment_date
    )

def g(row, col, default=""):
    """Safe column getter."""
    return row[col] if col < len(row) else default


def build_so_master_lookup(tab_data: Dict[str, List[List[str]]]) -> Dict[str, dict]:
    """Build unified SO master lookup from all FMS 1 tabs."""
    so_info = {}

    def get_so(so_raw):
        if not so_raw: return None
        s = cs(so_raw)
        if not s or s.upper() in ['NA','N/A','-','#REF!','#N/A','SO NO','SO NO.']: return None
        if s not in so_info:
            so_info[s] = {
                'so': s, 'customer': 'N/A', 'po': 'N/A',
                'vendor': 'N/A', 'despatch': 'N/A', 'delivery': 'N/A', 'shipment': 'N/A'
            }
        return so_info[s]

    # 1. SOTOPO: Col 1 = SO, Col 5 = Customer
    for r in tab_data.get("SOTOPO", [])[7:]:
        s = get_so(g(r, 1))
        cust = cs(g(r, 5))
        if s and cust and cust.upper() not in ['#N/A','NA','N/A','-','NAME','CUSTOMER']:
            s['customer'] = cust

    # 2. PaymentCRM: Col 0 = SO, Col 4 = Client
    for r in tab_data.get("PaymentCRM", [])[7:]:
        s = get_so(g(r, 0))
        cust = cs(g(r, 4))
        if s and cust and cust.upper() not in ['#N/A','NA','N/A','-','NAME','CLIENT']:
            s['customer'] = cust

    # 3. Delivery: Col 0 = SO, Col 2 = Name
    for r in tab_data.get("Delivery", [])[7:]:
        s = get_so(g(r, 0))
        cust = cs(g(r, 2))
        if s and cust and cust.upper() not in ['#N/A','NA','N/A','-'] and s['customer'] == 'N/A':
            s['customer'] = cust

    # 4. invoiceandpayment: Col 2 = SO, Col 1 = Name
    for r in tab_data.get("invoiceandpayment", [])[2:]:
        s = get_so(g(r, 2))
        cust = cs(g(r, 1))
        if s and cust and cust.upper() not in ['#N/A','NA','N/A','-'] and s['customer'] == 'N/A':
            s['customer'] = cust

    # 5. GeneratePO: Col 2 = PO, Col 3 = SO, Col 4 = Vendor, Col 9 = Cust, Col 10 = Desp, Col 11 = Deliv, Col 12 = Ship
    for r in tab_data.get("GeneratePO", [])[7:]:
        s = get_so(g(r, 3))
        po = cs(g(r, 2))
        v = cs(g(r, 4))
        cust = cs(g(r, 9))
        desp = cs(g(r, 10))
        deliv_d = cs(g(r, 11))
        ship = cs(g(r, 12))
        if s:
            if po and po.upper() not in ['#N/A','NA','N/A','-']: s['po'] = po
            if v and v.upper() not in ['#N/A','NA','N/A','-']: s['vendor'] = v
            if cust and cust.upper() not in ['#N/A','NA','N/A','-'] and s['customer'] == 'N/A': s['customer'] = cust
            if desp and desp.upper() not in ['#N/A','NA','N/A','-']: s['despatch'] = desp
            if deliv_d and deliv_d.upper() not in ['#N/A','NA','N/A','-']: s['delivery'] = deliv_d
            if ship and ship.upper() not in ['#N/A','NA','N/A','-']: s['shipment'] = ship

    return so_info


def parse_otd(rows: List[List[str]], tab: str, so_lookup: Dict[str, dict] = None) -> List[TaskItem]:
    """Parse Order to Dispatch FMS (fms_1) according to Master SOD Mapping."""
    tasks = []
    fid, fn = "fms_1", "1. Order to Dispatch FMS"
    if so_lookup is None: so_lookup = {}

    if tab == "SOTOPO":
        for i in range(7, len(rows)):
            row = rows[i]
            so = cs(g(row,1)); cust = cs(g(row,5))
            info = so_lookup.get(so, {})
            customer = info.get('customer') or cust or 'N/A'
            po = info.get('po') or 'N/A'
            vendor = info.get('vendor') or 'N/A'
            desp = info.get('despatch') or 'N/A'
            deliv_d = info.get('delivery') or 'N/A'
            ship = info.get('shipment') or 'N/A'
            entity = f"{so} – {customer}".strip(" –") if so else None
            if not entity: continue

            # SO1: AMOL | Planned: H (7), Actual: I (8)
            t = make_task(f"SO1-{i}", fid, fn, tab, i+1, entity,
                "Is SO Approved ? (if no get it edited if needed)", "AMOL",
                parse_date(g(row,7)), parse_date(g(row,8)), cs(g(row,10)),
                so_no=so, po_no=po, customer_name=customer, vendor_name=vendor,
                despatch_date=desp, delivery_date=deliv_d, shipment_date=ship)
            if t: tasks.append(t)

            # SO2: LALIT | Planned: M (12), Actual: N (13)
            t = make_task(f"SO2-{i}", fid, fn, tab, i+1, entity,
                "is ALL material available ?", "LALIT",
                parse_date(g(row,12)), parse_date(g(row,13)), cs(g(row,15)),
                so_no=so, po_no=po, customer_name=customer, vendor_name=vendor,
                despatch_date=desp, delivery_date=deliv_d, shipment_date=ship)
            if t: tasks.append(t)

            # SO3: PRAKASH | Planned: R (17), Actual: S (18)
            t = make_task(f"SO3-{i}", fid, fn, tab, i+1, entity,
                "Generate all PO and Fill PO Google Form", "PRAKASH",
                parse_date(g(row,17)), parse_date(g(row,18)), cs(g(row,20)),
                so_no=so, po_no=po, customer_name=customer, vendor_name=vendor,
                despatch_date=desp, delivery_date=deliv_d, shipment_date=ship)
            if t: tasks.append(t)

            # SO4: CRM | Planned: W (22), Actual: X (23)
            t = make_task(f"SO4-{i}", fid, fn, tab, i+1, entity,
                "Order Against Purchase Order", "CRM",
                parse_date(g(row,22)), parse_date(g(row,23)), cs(g(row,25)),
                so_no=so, po_no=po, customer_name=customer, vendor_name=vendor,
                despatch_date=desp, delivery_date=deliv_d, shipment_date=ship)
            if t: tasks.append(t)

    elif tab == "GeneratePO":
        for i in range(7, len(rows)):
            row = rows[i]
            po_raw = cs(g(row,2)); so = cs(g(row,3)); vendor_raw = cs(g(row,4))
            info = so_lookup.get(so, {})
            customer = info.get('customer') or cs(g(row,9)) or 'N/A'
            po = po_raw or info.get('po') or 'N/A'
            vendor = vendor_raw or info.get('vendor') or 'N/A'
            desp = cs(g(row,10)) or info.get('despatch') or 'N/A'
            deliv_d = cs(g(row,11)) or info.get('delivery') or 'N/A'
            ship = cs(g(row,12)) or info.get('shipment') or 'N/A'
            entity = f"PO:{po} | SO:{so} ({vendor})" if po and po != 'N/A' else (f"{so} – {customer}" if so else None)
            if not entity or len(entity) < 5: continue

            specs = [
                # PO1: PRAKASH | Planned: N (13), Actual: O (14)
                ("PO1", "Issue PO to Supplier",                     13, 14, 17, "PRAKASH"),
                # PO2: MIS | Planned: S (18), Actual: T (19)
                ("PO2", "Update Despatch-Delivery-Shimpent date",   18, 19, 21, "MIS"),
                # PO3: PC | Planned: W (22), Actual: X (23)
                ("PO3", "Follow up with Courier company",           22, 23, 25, "PC"),
                # PO4: PC | Planned: AA (26), Actual: AB (27)
                ("PO4", "Recieve Material",                         26, 27, 29, "PC"),
                # PO5: CRM | Planned: AE (30), Actual: AF (31)
                ("PO5", "bill entry",                               30, 31, 33, "CRM"),
                # PO6: PC | Planned: AI (34), Actual: AJ (35)
                ("PO6", "bill filing",                              34, 35, 37, "PC"),
            ]
            for code, step, pc, ac, sc, doer in specs:
                t = make_task(f"{code}-{i}", fid, fn, tab, i+1, entity,
                    step, doer, parse_date(g(row,pc)), parse_date(g(row,ac)), cs(g(row,sc)),
                    so_no=so or 'N/A', po_no=po, customer_name=customer, vendor_name=vendor,
                    despatch_date=desp, delivery_date=deliv_d, shipment_date=ship)
                if t: tasks.append(t)

    elif tab == "PaymentCRM":
        for i in range(7, len(rows)):
            row = rows[i]
            so = cs(g(row,0)); client = cs(g(row,4))
            info = so_lookup.get(so, {})
            customer = info.get('customer') or client or 'N/A'
            po = info.get('po') or 'N/A'
            vendor = info.get('vendor') or 'N/A'
            desp = info.get('despatch') or 'N/A'
            deliv_d = info.get('delivery') or 'N/A'
            ship = info.get('shipment') or 'N/A'
            entity = f"{so} – {customer}".strip(" –") if so else None
            if not entity: continue

            specs = [
                # PA1: CRM | Planned: H (7), Actual: I (8)
                ("PA1", "Inform Shipment Date to Client & Interior",                           7,  8, 10, "CRM"),
                # PA2: CRM | Planned: L (11), Actual: M (12)
                ("PA2", "Follow up 5 days before shipment day for advance payment",          11, 12, 14, "CRM"),
                # PA3: CRM | Planned: P (15), Actual: Q (16)
                ("PA3", "Follow up for advance payment (2 days before shipment day)",         15, 16, 18, "CRM"),
                # PA4: CRM | Planned: T (19), Actual: U (20)
                ("PA4", "Adjusted follow up",                                                 19, 20, 22, "CRM"),
            ]
            for code, step, pc, ac, sc, doer in specs:
                t = make_task(f"{code}-{i}", fid, fn, tab, i+1, entity,
                    step, doer, parse_date(g(row,pc)), parse_date(g(row,ac)), cs(g(row,sc)),
                    so_no=so or 'N/A', po_no=po, customer_name=customer, vendor_name=vendor,
                    despatch_date=desp, delivery_date=deliv_d, shipment_date=ship)
                if t: tasks.append(t)

    elif tab == "Delivery":
        for i in range(7, len(rows)):
            row = rows[i]
            so = cs(g(row,0)); name = cs(g(row,2))
            info = so_lookup.get(so, {})
            customer = info.get('customer') or name or 'N/A'
            po = info.get('po') or 'N/A'
            vendor = info.get('vendor') or 'N/A'
            desp = info.get('despatch') or 'N/A'
            deliv_d = info.get('delivery') or 'N/A'
            ship = info.get('shipment') or 'N/A'
            entity = f"{so} – {customer}".strip(" –") if so else None
            if not entity: continue

            specs = [
                # DE1: LALIT | Planned: I (8), Actual: J (9)
                ("DE1", "Inform about shipment is packed & ready",                                                                        8,  9, 11, "LALIT"),
                # DE2: CRM | Planned: M (12), Actual: N (13)
                ("DE2", "Generate Invoice+Packaging slip (+delivery note if needed) (+waybill if needed) or delivery chalan",          12, 13, 15, "CRM"),
                # DE3: PC | Planned: Q (16), Actual: R (17)
                ("DE3", "Assigning of delivery Person",                                                                                  16, 17, 19, "PC"),
            ]
            for code, step, pc, ac, sc, doer in specs:
                t = make_task(f"{code}-{i}", fid, fn, tab, i+1, entity,
                    step, doer, parse_date(g(row,pc)), parse_date(g(row,ac)), cs(g(row,sc)),
                    so_no=so or 'N/A', po_no=po, customer_name=customer, vendor_name=vendor,
                    despatch_date=desp, delivery_date=deliv_d, shipment_date=ship)
                if t: tasks.append(t)

    elif tab == "invoiceandpayment":
        for i in range(2, len(rows)):
            row = rows[i]
            client = cs(g(row,1)); so = cs(g(row,2)); inv = cs(g(row,4))
            if "INVOICE NO" in inv.upper() or "SO NO" in so.upper() or client.upper() == "NAME": continue
            info = so_lookup.get(so, {})
            customer = info.get('customer') or client or 'N/A'
            po = info.get('po') or 'N/A'
            vendor = info.get('vendor') or 'N/A'
            desp = info.get('despatch') or 'N/A'
            deliv_d = info.get('delivery') or 'N/A'
            ship = info.get('shipment') or 'N/A'
            entity = f"{inv} | {so} – {customer}".strip(" | –") if (inv or so) else None
            if not entity: continue

            # IP1: CRM | Planned: J (9), Actual: K (10)
            t = make_task(f"IP1-{i}", fid, fn, tab, i+1, entity,
                "Inform Delivery/Return of materials to Client & Interior", "CRM",
                parse_date(g(row,9)), parse_date(g(row,10)), cs(g(row,12)),
                so_no=so or 'N/A', po_no=po, customer_name=customer, vendor_name=vendor,
                despatch_date=desp, delivery_date=deliv_d, shipment_date=ship)
            if t: tasks.append(t)

    return tasks


# ─────────────────────────────────────────────
# Parser: Order Enquiry  (fms_2)
# ─────────────────────────────────────────────
# CONFIRMED SCHEMA: row1=headers (full step names)
# col0=date, col1=ENQ no, col2=Enquiry Name, col10=Sale, col11=STATUS
# col12=Designer, col13=Salesperson (Lights), col14=Automation Salesperson
# Steps A1-A16: each 5 cols: planned, actual, delay, STEP status, Doer
# Step A1: planned=col23, actual=col24, status=col26, doer=col27
# Step A2: planned=col28, actual=col29, status=col31, doer=col32
# Step A3: planned=col33, actual=col34, status=col36, doer=col37
# etc. +5 each time

def parse_order_enquiry(rows: List[List[str]]) -> List[TaskItem]:
    """Parse Order Enquiry FMS (fms_2) according to Master SOD Mapping:
    - 16 Steps: A1 to A16 with exact column ranges and doers from user master table
    - Metadata: enq_no (Col 1), enq_name (Col 2), enq_date (Col 0), sale_status (Col 10),
      overall_status (Col 11), revision_req (Col 20)
    """
    tasks = []
    fid, fn = "fms_2", "2. Order Enquiry FMS"
    
    # Exact step definitions from user master table:
    # (code, step_name, planned_col, actual_col, status_col, doer_col)
    STEPS = [
        ("A1",  "ASK CAD OR BOQ",                   23, 24, 26, 27),
        ("A2",  "BUDGET",                           28, 29, 31, 32),
        ("A3",  "MOCK-UP/ SHOWROOM VISIT",          33, 34, 36, 37),
        ("A4",  "Finish CAD drawing",               38, 39, 41, 42),
        ("A5",  "BOQ",                              43, 44, 46, 47),
        ("A6",  "Finish Lighting quote",            48, 49, 51, 52),
        ("A7",  "Finish Automation quote",          53, 54, 56, 57),
        ("A8",  "Send quote to client",             58, 59, 61, 62),
        ("A9",  "FOLLOW UP",                        63, 64, 66, 67),
        ("A10", "advance payment",                  68, 69, 71, 72),
        ("A11", "PRESENTATION",                     73, 74, 76, 77),
        ("A12", "Finish revised CAD drawing",       78, 79, 81, 82),
        ("A13", "Finish revised Lighting quote",    83, 84, 86, 87),
        ("A14", "Finish revised Automation quote",  88, 89, 91, 92),
        ("A15", "Send revised quote to client",     93, 94, 96, 97),
        ("A16", "FOLLOW UP FOR revised quote",      98, 99, 101, 102),
    ]
    
    for i in range(1, len(rows)):
        row = rows[i]
        enq_date = cs(g(row, 0))
        enq_no = cs(g(row, 1))
        enq_name = cs(g(row, 2))
        sale_status = cs(g(row, 10))       # Win, Loss, In progress, Closed
        overall_status = cs(g(row, 11))    # closed, ongoing, cancel
        revision_req = cs(g(row, 20))      # YES, NO
        if not enq_no and not enq_name: continue
        entity = f"{enq_no} – {enq_name}".strip(" –")
        
        rev_text = "YES" if "YES" in revision_req.upper() else "NO"
        
        for step_code, step_name, pc, ac, sc, dc in STEPS:
            raw_doer = cs(g(row, dc))
            norm_d = normalize_doer(raw_doer)
            # User rule: "PLZ NA KO SALES TEM COSIDER MTT KRO JO NA HAI WO COUNT NHI HOGA JISKA DOER NA HAI WO COUNT NHI HOGA"
            if not norm_d or norm_d == "UNASSIGNED" or norm_d in {"NA", "N/A", "NONE", "0"}:
                continue

            p_date = parse_date(g(row, pc))
            a_date = parse_date(g(row, ac))
            raw_st = cs(g(row, sc))

            t = make_task(
                f"ENQ-{step_code}-{i}", fid, fn, "MASTER", i+1, entity,
                step_name, norm_d, p_date, a_date, raw_st,
                so_no=enq_no or "N/A",
                po_no=rev_text,
                customer_name=enq_name or "N/A",
                vendor_name=sale_status or "In progress",
                despatch_date=enq_date or "N/A",
                delivery_date=overall_status or "N/A",
                shipment_date=f"Revision: {rev_text}"
            )
            if t: tasks.append(t)

    return tasks


def clean_amount(raw: Any) -> float:
    s = cs(raw).replace(',', '').replace('₹', '').strip()
    try:
        val = float(s)
        return int(val) if val.is_integer() else round(val, 2)
    except Exception:
        return 0


def parse_enquiry_pipeline(rows: List[List[str]]) -> List[Dict[str, Any]]:
    """Parse Order Enquiry FMS into a Sales Pipeline / Ongoing Enquiries report."""
    pipeline = []

    MASTER_STEPS = [
        ("A1",  "Ask CAD or BOQ",                      23, 24),
        ("A2",  "Budget Discussion",                   28, 29),
        ("A3",  "Mock-up / Showroom Visit",            33, 34),
        ("A4",  "Finish CAD Drawing",                  38, 39),
        ("A5",  "BOQ Preparation",                     43, 44),
        ("A6",  "Finish Lighting Quote",               48, 49),
        ("A7",  "Finish Automation Quote",             53, 54),
        ("A8",  "Send Quote to Client",                58, 59),
        ("A9",  "Follow-up with Client",               63, 64),
        ("A10", "Advance Payment",                     68, 69),
        ("A11", "Presentation",                        73, 74),
        ("A12", "Finish Revised CAD Drawing",          78, 79),
        ("A13", "Finish Revised Lighting Quote",       83, 84),
        ("A14", "Finish Revised Automation Quote",     88, 89),
        ("A15", "Send Revised Quote to Client",        93, 94),
        ("A16", "Follow-up for Revised Quote",         98, 99),
    ]

    for i in range(1, len(rows)):
        row = rows[i]
        enq_no = cs(g(row, 1))
        enq_name = cs(g(row, 2))
        date_str = cs(g(row, 0))
        if not enq_no and not enq_name:
            continue

        parsed_dt = parse_date(date_str)
        date_formatted = parsed_dt.strftime("%d/%m/%Y") if parsed_dt else date_str

        light_quote_no = cs(g(row, 6)) or "N/A"
        light_quote_amt = clean_amount(g(row, 7))
        auto_quote_amt = clean_amount(g(row, 8))
        auto_quote_no = cs(g(row, 9)) or "N/A"
        sale_status = cs(g(row, 10)) or "In progress"
        overall_status = cs(g(row, 11)) or "ongoing"

        raw_doer = cs(g(row, 13)) or cs(g(row, 14)) or cs(g(row, 12))
        norm_doer = normalize_doer(raw_doer)
        if norm_doer in ["UNASSIGNED", "NA", "N/A", "NONE", "0"]:
            norm_doer = "Unassigned"

        # Determine stuck step: first step where actual date is missing
        stuck_step = "All Steps Completed"
        for code, sname, pc, ac in MASTER_STEPS:
            a_val = cs(g(row, ac))
            a_date = parse_date(a_val)
            if not a_date:
                stuck_step = f"{code}: {sname}"
                break

        pipeline.append({
            "row_index": i + 1,
            "date_raw": date_str,
            "date_sort": parsed_dt.isoformat() if parsed_dt else "1970-01-01",
            "date": date_formatted,
            "enq_no": enq_no or "N/A",
            "enq_name": enq_name or "N/A",
            "doer": norm_doer,
            "light_quote_no": light_quote_no,
            "light_quote_amt": light_quote_amt,
            "auto_quote_amt": auto_quote_amt,
            "auto_quote_no": auto_quote_no,
            "total_quote_amt": light_quote_amt + auto_quote_amt,
            "sale_status": sale_status,
            "overall_status": overall_status,
            "stuck_step": stuck_step
        })

    pipeline.sort(key=lambda x: x["date_sort"], reverse=True)
    return pipeline


# ─────────────────────────────────────────────
# Parser: Delegation  (fms_3)
# ─────────────────────────────────────────────
# CONFIRMED: data from row1 (index 0)
# col0=Task ID, col1=Doer Name, col2=Task, col3=First Date, col6=Latest Revision, col7=ACTUAL TIME, col9=Status

def parse_delegation(rows: List[List[str]]) -> List[TaskItem]:
    tasks = []
    fid, fn = "fms_3", "3. Delegation FMS"
    for i in range(1, len(rows)):
        row = rows[i]
        task_id = cs(g(row,0)); doer = cs(g(row,1)); desc = cs(g(row,2))
        if not desc: continue
        entity = f"#{task_id}: {desc}" if task_id else desc
        planned = parse_date(g(row,6)) or parse_date(g(row,3))
        actual = parse_date(g(row,7))
        status = cs(g(row,9))
        t = make_task(f"DEL-{i}", fid, fn, "Master", i+1, entity,
            desc, doer, planned, actual, status)
        if t: tasks.append(t)
    return tasks


# ─────────────────────────────────────────────
# Parser: Checklist  (fms_4)
# ─────────────────────────────────────────────
# CONFIRMED: data from row1 (index0)
# col0=Doer, col3=ID, col5=Task description, col6=Planned date, col7=Actual date

def parse_checklist(rows: List[List[str]]) -> List[TaskItem]:
    tasks = []
    fid, fn = "fms_4", "4. Checklist FMS"
    for i in range(1, len(rows)):
        row = rows[i]
        doer = cs(g(row,0)); tid = cs(g(row,3)); desc = cs(g(row,5))
        if not desc: continue
        entity = f"#{tid}: {desc}" if tid else desc
        planned = parse_date(g(row,6))
        actual = parse_date(g(row,7))
        status = "Completed" if actual else "Pending"
        t = make_task(f"CHK-{i}", fid, fn, "Master", i+1, entity,
            desc, doer, planned, actual, status)
        if t: tasks.append(t)
    return tasks


# ─────────────────────────────────────────────
# Parser: Return FMS  (fms_5)
# ─────────────────────────────────────────────
# CONFIRMED: meta rows 1-6, data from row7 (index6)
# Row4 (index3): doer at col10 = PRAKASH
# col1=Return key, col2=SO, col4=Site, col6=planned, col7=actual, col10=step "DC return/credit note"

def parse_return(rows: List[List[str]]) -> List[TaskItem]:
    """Parse Return FMS (fms_5) according to Master SOD Mapping:
    - 3 Steps from user master table:
      1. A1: ADD TO SHIPMENT LIST (G8:H -> Cols 6, 7) -> Doer: MIS
      2. A2: Do DC return and create credit note (K8:L -> Cols 10, 11) -> Doer: PRAKASH
      3. A3: informed client about retun successfully (O8:P -> Cols 14, 15) -> Doer: CRM
    - Metadata:
      Col 1: Unique Key (e.g. RETURN-0001)
      Col 2: SO Number
      Col 3: Invoice Number
      Col 4: Site name
      Col 5: Item Name
    """
    tasks = []
    fid, fn = "fms_5", "5. Return FMS"
    
    RETURN_STEPS = [
        ("A1", "ADD TO SHIPMENT LIST",                     6,  7,  "MIS"),
        ("A2", "Do DC return and create credit note",      10, 11, "PRAKASH"),
        ("A3", "informed client about retun successfully", 14, 15, "CRM"),
    ]

    for i in range(6, len(rows)):
        row = rows[i]
        rk = cs(g(row, 1))
        so = cs(g(row, 2))
        inv = cs(g(row, 3))
        site = cs(g(row, 4))
        item = cs(g(row, 5))
        if not rk and not so and not site:
            continue
        entity = f"{rk} | {site}" if site else rk
        
        for code, step_name, pc, ac, doer in RETURN_STEPS:
            p_date = parse_date(g(row, pc))
            a_date = parse_date(g(row, ac))
            raw_st = "Completed" if a_date else "Pending"

            t = make_task(
                f"RET-{code}-{i}", fid, fn, "RETURNFMS", i+1, entity,
                step_name, doer, p_date, a_date, raw_st,
                so_no=so or "N/A",
                po_no=rk or "N/A",            # Unique Key
                customer_name=site or "N/A",   # Site name
                vendor_name=item or "N/A",     # Item Name
                despatch_date=inv or "N/A",    # Invoice Number
                delivery_date=rk or "N/A",     # Unique Key
                shipment_date="N/A"
            )
            if t: tasks.append(t)

    return tasks


# ─────────────────────────────────────────────
# Parser: After Sales  (fms_6)
# ─────────────────────────────────────────────
# CONFIRMED Dashboard: data from row2 (index1)
# col0=Issue ID, col1=Site, col2=Type, col3=Reported date, col4=Status, col5=Planned visit,
# col6=Doer, col12=Resolved date

def parse_after_sales(rows: List[List[str]], tab: str, dash_completed: Optional[Dict[str, Any]] = None) -> List[TaskItem]:
    """Parse After Sales FMS (fms_6) supporting both:
    1. 'FMS For View only': 4 Master SOD steps Z1-Z4
    2. 'Dashboard': Assigned Doer site resolution report
    """
    if dash_completed is None:
        dash_completed = {}
    tasks = []
    fid, fn = "fms_6", "6. After Sales FMS"
    cleaned_tab = tab.strip()

    if cleaned_tab == "FMS For View only":
        # Master Steps Z1 to Z4 from user screenshot:
        VIEW_STEPS = [
            ("Z1", "Message after sales issue registration and provide a visit date.", 4, 5, 7),
            ("Z2", "Technician to talk to client, interior team, and electrician one day before visit date", 8, 9, 11),
            ("Z3", "UPDATE OF VISIT (If required, provide a new visit date.)", 12, 13, 15),
            ("Z4", "MAKE DC", 16, 17, 19),
        ]
        for i in range(2, len(rows)):
            row = rows[i]
            uk = cs(g(row, 1))
            site = cs(g(row, 2))
            visit_date = cs(g(row, 3))
            if not uk and not site:
                continue
            entity = f"{uk} – {site}".strip(" –")

            is_issue_completed = uk in dash_completed

            for code, step_name, pc, ac, dc in VIEW_STEPS:
                p_date = parse_date(g(row, pc))
                a_date = parse_date(g(row, ac))
                raw_doer = cs(g(row, dc))
                if not raw_doer and code in ["Z1", "Z2", "Z3"]:
                    raw_doer = "PC"
                if not raw_doer:
                    continue

                # If the whole issue is completed in Dashboard, and step actual date is blank, resolve it
                if not a_date and is_issue_completed:
                    a_date = dash_completed.get(uk) or p_date

                raw_st = "Completed" if a_date else "Pending"

                t = make_task(
                    f"AFS-V-{code}-{i}", fid, fn, "FMS For View only", i+1, entity,
                    step_name, raw_doer, p_date, a_date, raw_st,
                    so_no=uk or "N/A",               # Unique Key (Issue ID)
                    po_no=visit_date or "N/A",       # Visit Date
                    customer_name=site or "N/A",     # Site Name
                    vendor_name="After Sales",
                    despatch_date=visit_date or "N/A",
                    delivery_date=uk or "N/A",
                    shipment_date="N/A"
                )
                if t: tasks.append(t)

    elif cleaned_tab == "Dashboard":
        # Dashboard sheet report by Assigned Doer:
        # Col 0: Issue ID, Col 1: Site Name, Col 2: Category, Col 3: Issue Date, Col 4: Status
        # Col 5: Plan Date, Col 6: Assigned Doer, Col 11: Last Visit Date, Col 12: Completion Date
        for i in range(1, len(rows)):
            row = rows[i]
            iss = cs(g(row, 0))
            site = cs(g(row, 1))
            cat = cs(g(row, 2))
            status = cs(g(row, 4))
            plan_date = parse_date(g(row, 5)) or parse_date(g(row, 3))
            doer = cs(g(row, 6))
            last_visit = cs(g(row, 11))
            comp_date = parse_date(g(row, 12))
            if not iss and not site:
                continue
            if not doer or doer.upper() in {"NULL", "NA", "N/A"}:
                continue
            entity = f"{iss} – {site}".strip(" –")

            # If Status in sheet is explicitly "Completed" but Completion Date is blank:
            if status.strip().lower() in ["completed", "complete", "closed", "done"] and comp_date is None:
                comp_date = parse_date(last_visit) or plan_date or parse_date(g(row, 3))

            t = make_task(
                f"AFS-D-{i}", fid, fn, "Dashboard", i+1, entity,
                "After Sales Site Resolution", doer,
                plan_date, comp_date, status,
                so_no=iss or "N/A",               # Issue ID
                po_no=cat or "N/A",               # Category
                customer_name=site or "N/A",     # Site Name
                vendor_name=cat or "N/A",         # Category
                despatch_date=last_visit or "N/A",# Visit Date
                delivery_date=iss or "N/A",       # Issue ID
                shipment_date="N/A"
            )
            if t: tasks.append(t)

    return tasks


# ─────────────────────────────────────────────
# Parser: Delivery Challan  (fms_7)
# ─────────────────────────────────────────────
# CONFIRMED: meta rows 1-6, data from row7 (index6)
# col0=ID, col2=SO/Name, col4=DC no, col17=Doer(CRM)
# Planned/Actual need to find from actual data rows

def parse_dc(rows: List[List[str]]) -> List[TaskItem]:
    """Parse Delivery Challan FMS (fms_7) according to Master SOD Mapping:
    - 6 Steps from user master table:
      1. A1: Generate DC and fill form (FMS!G8:H -> Cols 6, 7) -> Doer: CRM
      2. A2: MAake godown slip (FMS!K8:L -> Cols 10, 11) -> Doer: PRAKASH
      3. A3: Assigning of dlivery Person (FMS!O8:Q -> Cols 14, 15) -> Doer: MEET
      4. A4: Inform Delivery of materials to Client & Interior (FMS!S8:T -> Cols 18, 19) -> Doer: CRM
      5. A5: call for update and return (FMS!W8:X -> Cols 22, 23) -> Doer: CRM
      6. A6: Auto MIAC (FMS!AA8:AB -> Cols 26, 27) -> Doer: CRM
    - Metadata:
      Col 0: Unique Key (e.g. DC-0001)
      Col 2: SO NAME
      Col 3: SO NO
      Col 4: DC NO
      Col 5: DC DATE
    """
    tasks = []
    fid, fn = "fms_7", "7. Delivery Challan FMS"

    DC_STEPS = [
        ("A1", "Generate DC and fill form",                     6,  7,  "CRM"),
        ("A2", "MAake godown slip",                             10, 11, "PRAKASH"),
        ("A3", "Assigning of dlivery Person",                   14, 15, "MEET"),
        ("A4", "Inform Delivery of materials to Client & Int.", 18, 19, "CRM"),
        ("A5", "call for update and return",                    22, 23, "CRM"),
        ("A6", "Auto MIAC",                                     26, 27, "CRM"),
    ]

    for i in range(6, len(rows)):
        row = rows[i]
        uk = cs(g(row, 0))
        so_name = cs(g(row, 2))
        so_no = cs(g(row, 3))
        dc_no = cs(g(row, 4))
        dc_date = cs(g(row, 5))
        if not uk and not so_name and not dc_no:
            continue
        entity = f"{uk} | {so_name}" if so_name else uk

        for code, step_name, pc, ac, doer in DC_STEPS:
            p_date = parse_date(g(row, pc))
            a_date = parse_date(g(row, ac))
            if p_date is None and a_date is None:
                continue
            raw_st = "Completed" if a_date else "Pending"

            t = make_task(
                f"DC-{code}-{i}", fid, fn, "Fms", i+1, entity,
                step_name, doer, p_date, a_date, raw_st,
                so_no=so_no or "N/A",           # SO NO
                po_no=uk or "N/A",              # Unique Key
                customer_name=so_name or "N/A", # SO NAME
                vendor_name=dc_no or "N/A",     # DC NO
                despatch_date=dc_date or "N/A", # DC DATE
                delivery_date=dc_no or "N/A",   # DC NO
                shipment_date="N/A"
            )
            if t: tasks.append(t)

    return tasks


# ─────────────────────────────────────────────
# Parser: Commission  (fms_8)
# ─────────────────────────────────────────────
# CONFIRMED: data from row3 (index2)
# col0=date, col1=ENQ no, col2=Name, col7=status, col10=planned, col11=actual

def parse_commission(rows: List[List[str]]) -> List[TaskItem]:
    """Parse Commission FMS (fms_8) according to Master SOD Mapping:
    - 6 Steps from user master table:
      1. A1: PUT COMMISSION % IN INVOICE DETAILS (FMS!K8:L -> Cols 10, 11) -> Doer: CRM
      2. A2: collect and categorize full payment (FMS!O8:P -> Cols 14, 15) -> Doer: CRM
      3. A3: informed Interior about total amount / accounts (FMS!S8:T -> Cols 18, 19) -> Doer: CRM
      4. A4: create commission bill against each invoice (FMS!W8:X -> Cols 22, 23) -> Doer: CRM
      5. A5: create payment summary report for approval (FMS!AA8:AB -> Cols 26, 27) -> Doer: CRM
      6. A6: Pyment (FMS!AE8:AF -> Cols 30, 31) -> Doer: PATRO DA
    - Metadata:
      Col 1: Unique Enquiry Number (e.g. ENQ-030)
      Col 2: Enquiry Name
      Col 7: Sale - Win/Loss
      Col 8: Interior Name
    """
    tasks = []
    fid, fn = "fms_8", "8. Commission FMS"

    COMM_STEPS = [
        ("A1", "PUT COMMISSION % IN INVOICE DETAILS",          10, 11, "CRM"),
        ("A2", "collect and categorize full payment",          14, 15, "CRM"),
        ("A3", "informed Interior about total amount / accounts", 18, 19, "CRM"),
        ("A4", "create commission bill against each invoice",  22, 23, "CRM"),
        ("A5", "create payment summary report for approval",   26, 27, "CRM"),
        ("A6", "Pyment",                                       30, 31, "PATRO DA"),
    ]

    for i in range(2, len(rows)):
        row = rows[i]
        enq_no = cs(g(row, 1))
        enq_name = cs(g(row, 2))
        sale_status = cs(g(row, 7))
        interior = cs(g(row, 8))
        if not enq_no and not enq_name:
            continue
        entity = f"{enq_no} – {enq_name}".strip(" –")

        for code, step_name, pc, ac, doer in COMM_STEPS:
            p_date = parse_date(g(row, pc))
            a_date = parse_date(g(row, ac))
            raw_st = "Completed" if a_date else "Pending"

            t = make_task(
                f"COMM-{code}-{i}", fid, fn, "Fms", i+1, entity,
                step_name, doer, p_date, a_date, raw_st,
                so_no=enq_no or "N/A",            # Unique Enquiry Number
                po_no=interior or "N/A",          # Interior Name
                customer_name=enq_name or "N/A",   # Enquiry Name
                vendor_name=sale_status or "In progress",
                despatch_date=enq_no or "N/A",
                delivery_date=interior or "N/A",
                shipment_date="N/A"
            )
            if t: tasks.append(t)

    return tasks


def parse_payment_crm(rows: List[List[str]]) -> Tuple[List[TaskItem], List[Dict[str, Any]]]:
    """Parse Payment CRM ledger for financial recovery tracking and dashboard integration."""
    tasks: List[TaskItem] = []
    records: List[Dict[str, Any]] = []
    fid, fn = "fms_9", "9. Payment CRM"

    for i in range(1, len(rows)):
        r = rows[i]
        name = cs(g(r, 1))
        so_no = cs(g(r, 2))
        so_amt = clean_amount(g(r, 3))
        inv_no = cs(g(r, 4))
        inv_dt = cs(g(r, 5))
        dc_no = cs(g(r, 6))
        dc_dt = cs(g(r, 7))
        inv_amt = clean_amount(g(r, 8))
        credit_period = cs(g(r, 9))
        salesperson = cs(g(r, 10))
        delivery_person = cs(g(r, 11))
        credit_note_ret = clean_amount(g(r, 13))
        out_amt = clean_amount(g(r, 14))
        overdue_dt_raw = cs(g(r, 15))
        overdue_days_raw = cs(g(r, 16))
        manual_dt_raw = cs(g(r, 17))
        act_dt_raw = cs(g(r, 18))
        amt_paid = clean_amount(g(r, 19))
        amt_paid_2 = clean_amount(g(r, 22))
        tot_paid = amt_paid + amt_paid_2

        if not name and not so_no and not inv_no:
            continue

        p_overdue = parse_date(overdue_dt_raw)
        p_manual = parse_date(manual_dt_raw)
        p_act = parse_date(act_dt_raw)

        days_val = 0
        try:
            days_val = int(float(overdue_days_raw))
        except Exception:
            days_val = 0

        # Status & Ageing
        if out_amt <= 0:
            pay_status = "Fully Paid"
        elif tot_paid > 0:
            pay_status = "Partially Paid"
        else:
            pay_status = "Payment Pending"

        if days_val <= 30:
            ageing = "0-30 Days"
        elif days_val <= 60:
            ageing = "31-60 Days"
        elif days_val <= 90:
            ageing = "61-90 Days"
        else:
            ageing = "90+ Days (Critical)"

        record = {
            "id": f"PAY-{i}",
            "row_index": i + 1,
            "customer_name": name or "N/A",
            "so_no": so_no or "N/A",
            "so_amt": so_amt,
            "inv_no": inv_no or "N/A",
            "inv_dt": inv_dt or "N/A",
            "dc_no": dc_no or "N/A",
            "dc_dt": dc_dt or "N/A",
            "inv_amt": inv_amt,
            "effective_amt": inv_amt if inv_amt > 0 else so_amt,
            "credit_period": credit_period or "N/A",
            "salesperson": salesperson or "N/A",
            "delivery_person": delivery_person or "N/A",
            "credit_note_ret": credit_note_ret,
            "out_amt": out_amt,
            "overdue_dt": overdue_dt_raw or "N/A",
            "overdue_iso": p_overdue.isoformat() if p_overdue else None,
            "days_overdue": days_val,
            "manual_dt": manual_dt_raw or "N/A",
            "manual_iso": p_manual.isoformat() if p_manual else None,
            "actual_dt": act_dt_raw or "N/A",
            "actual_iso": p_act.isoformat() if p_act else None,
            "amt_paid_1": amt_paid,
            "next_manual_dt": cs(g(r, 20)) or "N/A",
            "actual_dt_2": cs(g(r, 21)) or "N/A",
            "amt_paid_2": amt_paid_2,
            "amt_paid": tot_paid,
            "pay_status": pay_status,
            "ageing": ageing,
            "doer": "CRM"
        }
        records.append(record)

        planned_for_task = p_manual or p_overdue
        raw_status = "Completed" if out_amt <= 0 else "Pending"
        t = make_task(
            f"PAY-TASK-{i}", fid, fn, "Payment CRM", i + 1,
            f"{so_no or inv_no} – {name}", "Payment Collection", "CRM",
            planned_for_task, p_act if out_amt <= 0 else None, raw_status,
            so_no=so_no or "N/A", po_no=inv_no or "N/A",
            customer_name=name or "N/A", vendor_name=salesperson or "N/A",
            despatch_date=manual_dt_raw or overdue_dt_raw or "N/A",
            delivery_date=str(out_amt), shipment_date=f"Paid: {tot_paid}"
        )
        if t:
            tasks.append(t)

    return tasks, records


# ─────────────────────────────────────────────
# Main fetch + parse
# ─────────────────────────────────────────────
def fetch_and_parse_all_sheets(force_refresh: bool = False) -> List[TaskItem]:
    global DATA_CACHE
    now = datetime.now()
    if not force_refresh and DATA_CACHE["timestamp"] and (now - DATA_CACHE["timestamp"]).total_seconds() < 600:
        return DATA_CACHE["tasks"]

    all_tasks: List[TaskItem] = []
    tab_data = {}

    with concurrent.futures.ThreadPoolExecutor(max_workers=14) as ex:
        futures = {ex.submit(fetch_csv, cfg["sheet_id"], tab): (cfg, tab)
                   for cfg in FMS_CONFIGS for tab in cfg["tabs"]}
        for fut in concurrent.futures.as_completed(futures):
            try:
                cfg, tab = futures[fut]
                tab_data[(cfg["id"], tab)] = fut.result()
            except Exception as e:
                cfg, tab = futures[fut]
                print(f"[ERROR] {cfg['name']}/{tab}: {e}")

    # Build unified SO master lookup from all FMS 1 tabs
    fms1_tabs = {tab: tab_data.get(("fms_1", tab), []) for tab in ["SOTOPO", "GeneratePO", "PaymentCRM", "invoiceandpayment", "Delivery"]}
    so_lookup = build_so_master_lookup(fms1_tabs)

    # Build completed issues map from After Sales Dashboard
    dash_rows = tab_data.get(("fms_6", "Dashboard"), [])
    dash_completed = {}
    for r in dash_rows[1:]:
        iss = cs(g(r, 0))
        st = cs(g(r, 4))
        if iss and st.lower() in ["completed", "complete", "closed", "done"]:
            last_v = cs(g(r, 11))
            pl = parse_date(g(r, 5)) or parse_date(g(r, 3))
            cp = parse_date(g(r, 12)) or parse_date(last_v) or pl or parse_date(g(r, 3))
            dash_completed[iss] = cp

    crm_all_records: List[Dict[str, Any]] = []

    for (fid, tab), rows in tab_data.items():
        if fid == "fms_1": all_tasks.extend(parse_otd(rows, tab, so_lookup))
        elif fid == "fms_2": all_tasks.extend(parse_order_enquiry(rows))
        elif fid == "fms_3": all_tasks.extend(parse_delegation(rows))
        elif fid == "fms_4": all_tasks.extend(parse_checklist(rows))
        elif fid == "fms_5": all_tasks.extend(parse_return(rows))
        elif fid == "fms_6": all_tasks.extend(parse_after_sales(rows, tab, dash_completed))
        elif fid == "fms_7": all_tasks.extend(parse_dc(rows))
        elif fid == "fms_8": all_tasks.extend(parse_commission(rows))
        elif fid == "fms_9":
            crm_tasks, crm_records = parse_payment_crm(rows)
            all_tasks.extend(crm_tasks)
            crm_all_records.extend(crm_records)

    fms2_rows = tab_data.get(("fms_2", "MASTERSHEET"), [])
    DATA_CACHE["enquiry_pipeline"] = parse_enquiry_pipeline(fms2_rows)
    DATA_CACHE["payment_crm"] = crm_all_records

    DATA_CACHE["timestamp"] = now
    DATA_CACHE["tasks"] = all_tasks
    print(f"[INFO] Loaded {len(all_tasks)} tasks from all {len(FMS_CONFIGS)} FMS sheets (Payment CRM: {len(crm_all_records)} records).")
    return all_tasks


# ─────────────────────────────────────────────
# Report Generation
# ─────────────────────────────────────────────
def generate_report(
    fms_filter: str = "ALL",
    date_preset: str = "ALL_TIME",
    custom_start: Optional[str] = None,
    custom_end: Optional[str] = None,
    doer_filter: str = "ALL",
    status_filter: str = "ALL",
    force_refresh: bool = False
) -> AggregatedReport:

    tasks = fetch_and_parse_all_sheets(force_refresh=force_refresh)
    now = datetime.now()
    today = datetime(now.year, now.month, now.day)

    start_dt = end_dt = None
    if custom_start or custom_end:
        if custom_start:
            s = parse_date(custom_start)
            if s: start_dt = datetime(s.year, s.month, s.day, 0, 0, 0)
        if custom_end:
            e = parse_date(custom_end)
            if e: end_dt = datetime(e.year, e.month, e.day, 23, 59, 59)
    elif date_preset == "TODAY":
        start_dt = today
        end_dt = today.replace(hour=23, minute=59, second=59)
    elif date_preset == "YESTERDAY":
        d = today - timedelta(days=1)
        start_dt = d
        end_dt = d.replace(hour=23, minute=59, second=59)
    elif date_preset == "THIS_WEEK":
        # Monday of current week to today
        mon = today - timedelta(days=today.weekday())
        start_dt = mon
        end_dt = today.replace(hour=23, minute=59, second=59)
    elif date_preset == "LAST_WEEK":
        # Monday to Sunday of previous week
        last_mon = today - timedelta(days=today.weekday() + 7)
        last_sun = last_mon + timedelta(days=6)
        start_dt = last_mon
        end_dt = last_sun.replace(hour=23, minute=59, second=59)

    filtered: List[TaskItem] = []
    advance_done_ids: set = set()
    for t in tasks:
        if fms_filter != "ALL" and t.fms_id != fms_filter: continue
        if doer_filter != "ALL" and normalize_doer(t.doer) != normalize_doer(doer_filter): continue
        if status_filter != "ALL":
            if status_filter == "COMPLETED" and not t.is_completed: continue
            elif status_filter == "PENDING" and t.is_completed: continue
            elif status_filter == "ON_TIME" and not t.is_ontime: continue
            elif status_filter == "DELAYED" and (t.is_ontime or not t.is_completed): continue
            elif status_filter == "OVERDUE" and t.status != "Pending Overdue": continue
        if start_dt or end_dt:
            p = parse_date(t.planned_date)
            a = parse_date(t.actual_date)
            planned_in_range = p and (not start_dt or p >= start_dt) and (not end_dt or p <= end_dt)
            actual_in_range  = a and (not start_dt or a >= start_dt) and (not end_dt or a <= end_dt)
            if not planned_in_range and not actual_in_range:
                continue
            if actual_in_range and not planned_in_range and t.is_completed:
                advance_done_ids.add(t.id)
        filtered.append(t)

    # Known doers
    known = set(normalize_doer(t.doer) for t in tasks if t.doer) | set(PRIMARY_DOERS)
    known.discard("UNASSIGNED")
    available_doers = sorted(list(known))

    # Doer metrics dictionary
    doer_dict: Dict[str, DoerMetric] = {d: DoerMetric(doer=d) for d in available_doers}

    # 1. Period metrics (tasks in filtered list: planned or completed in selected range)
    for t in filtered:
        d = normalize_doer(t.doer)
        if d not in doer_dict: doer_dict[d] = DoerMetric(doer=d)
        dm = doer_dict[d]

        p = parse_date(t.planned_date)
        a = parse_date(t.actual_date)

        planned_in_range = p and (not start_dt or p >= start_dt) and (not end_dt or p <= end_dt)
        actual_in_range  = a and (not start_dt or a >= start_dt) and (not end_dt or a <= end_dt)

        if planned_in_range:
            dm.total_assigned += 1
            if t.is_completed and (not end_dt or (a and a <= end_dt)):
                dm.total_completed += 1
                if t.is_ontime: dm.ontime_completed += 1
                else: dm.delayed_completed += 1
            else:
                dm.total_pending += 1
        elif actual_in_range and t.is_completed:
            dm.advance_done += 1
            dm.total_completed += 1
            if t.is_ontime: dm.ontime_completed += 1
            else: dm.delayed_completed += 1

    # 2. Past Overdue Backlog across sheet tasks for each doer (planned BEFORE start_dt and uncompleted)
    now_today_start = datetime(now.year, now.month, now.day, 0, 0, 0)
    cutoff = end_dt if end_dt else (now_today_start.replace(hour=23, minute=59, second=59))
    as_of_limit = end_dt if end_dt else now

    for t in tasks:
        if fms_filter != "ALL" and t.fms_id != fms_filter: continue
        if doer_filter != "ALL" and normalize_doer(t.doer) != normalize_doer(doer_filter): continue
        d = normalize_doer(t.doer)
        if d not in doer_dict: continue
        dm = doer_dict[d]

        p = parse_date(t.planned_date)
        a = parse_date(t.actual_date)
        is_comp_as_of_limit = t.is_completed and (not end_dt or not a or a <= as_of_limit)

        if not is_comp_as_of_limit and p and p <= cutoff:
            dm.pending_overdue += 1

    doer_list = []
    for dm in doer_dict.values():
        dm.score_percentage = round(dm.ontime_completed / dm.total_assigned * 100, 1) if dm.total_assigned else 0.0
        # Rule 1: Work Done Score % (pending deficit)
        if dm.total_assigned == 0:
            dm.work_done_score = 0.0
        elif dm.total_completed == 0:
            dm.work_done_score = 100.0
        else:
            dm.work_done_score = round(max(0.0, (dm.total_assigned - dm.total_completed) / dm.total_assigned * 100), 1)

        # Rule 2: On-Time Delay Score % (0% = all on-time, 100% = all delayed)
        if dm.total_completed == 0:
            dm.ontime_delay_score = 0.0
        else:
            dm.ontime_delay_score = round(max(0.0, (dm.total_completed - dm.ontime_completed) / dm.total_completed * 100), 1)

        doer_list.append(dm)

    doer_list.sort(key=lambda x: (-x.total_assigned, -x.total_active_pending, -x.score_percentage))

    # FMS summaries
    fms_dict = {c["id"]: FMSReportSummary(fms_id=c["id"], fms_name=c["name"]) for c in FMS_CONFIGS}
    for t in filtered:
        if t.fms_id in fms_dict:
            fs = fms_dict[t.fms_id]
            fs.total_tasks += 1
            if t.is_completed:
                fs.completed_tasks += 1
                if t.is_ontime: fs.ontime_tasks += 1
            else: fs.pending_tasks += 1
    fms_list = []
    for fs in fms_dict.values():
        if fs.total_tasks: fs.overall_score = round(fs.ontime_tasks / fs.total_tasks * 100, 1)
        fms_list.append(fs)

    tot = len([t for t in filtered if t.id not in advance_done_ids])
    comp = sum(1 for t in filtered if t.is_completed and t.id not in advance_done_ids)
    ontime = sum(1 for t in filtered if t.is_completed and t.is_ontime and t.id not in advance_done_ids)
    delayed = sum(1 for t in filtered if t.is_completed and not t.is_ontime and t.id not in advance_done_ids)
    pending = sum(1 for t in filtered if not t.is_completed and t.id not in advance_done_ids)
    overdue = sum(1 for t in filtered if t.status == "Pending Overdue" and t.id not in advance_done_ids)

    # Build final task list — mark advance done tasks and include past overdue backlog tasks
    from dataclasses import replace as dc_replace
    task_items_out = []
    seen_ids = set()
    for t in filtered:
        seen_ids.add(t.id)
        if t.id in advance_done_ids:
            task_items_out.append(dc_replace(t, is_advance_done=True, status="Advance Done (Extra)"))
        else:
            task_items_out.append(dc_replace(t, is_advance_done=False))

    # Include past overdue backlog tasks in the detailed task table so the user can inspect them
    if start_dt or end_dt:
        now_today_start = datetime(now.year, now.month, now.day, 0, 0, 0)
        cutoff = start_dt if start_dt else now_today_start
        as_of_limit = end_dt if end_dt else now
        for t in tasks:
            if t.id in seen_ids: continue
            if fms_filter != "ALL" and t.fms_id != fms_filter: continue
            if doer_filter != "ALL" and normalize_doer(t.doer) != normalize_doer(doer_filter): continue
            p = parse_date(t.planned_date)
            a = parse_date(t.actual_date)
            is_comp = t.is_completed and (a and a <= as_of_limit)
            if not is_comp and p and p < cutoff:
                seen_ids.add(t.id)
                task_items_out.append(dc_replace(t, status="Pending Overdue (Past Backlog)"))

    fms_name = next((c["name"] for c in FMS_CONFIGS if c["id"] == fms_filter), "All 8 FMS (Combined Report)")

    return AggregatedReport(
        fms_id=fms_filter, fms_name=fms_name,
        date_preset=date_preset,
        start_date=start_dt.strftime("%Y-%m-%d") if start_dt else None,
        end_date=end_dt.strftime("%Y-%m-%d") if end_dt else None,
        total_assigned=tot, total_completed=comp,
        ontime_completed=ontime, delayed_completed=delayed,
        total_pending=pending, pending_overdue=overdue,
        overall_score_percentage=round(ontime/tot*100,1) if tot else 0.0,
        doer_metrics=doer_list, fms_summaries=fms_list,
        task_items=task_items_out[:1000] if date_preset == "ALL_TIME" else task_items_out,
        available_doers=available_doers,
        available_fms=[{"id": c["id"], "name": c["name"]} for c in FMS_CONFIGS]
    )
