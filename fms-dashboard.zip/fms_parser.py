import csv
import io
import re
import urllib.request
import urllib.parse
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
import concurrent.futures

from models import TaskItem, DoerMetric, FMSReportSummary, AggregatedReport

# ─────────────────────────────────────────────
# 9 FMS Configurations
# ─────────────────────────────────────────────
FMS_CONFIGS = [
    {"id": "fms_1", "name": "1. Order to Dispatch FMS",  "sheet_id": "10TbhEQXJBVqGu0jesUioaCuzxwPzu84hM98bVuL1qL0", "tabs": ["SOTOPO","GeneratePO","PaymentCRM","Delivery","invoiceandpayment"]},
    {"id": "fms_2", "name": "2. Order Enquiry FMS",       "sheet_id": "181kyeqN7Y2cWkHjNiRMwqeBGnY-WxNBbDyadhsxuOWU", "tabs": ["MASTERSHEET"]},
    {"id": "fms_3", "name": "3. Delegation FMS",          "sheet_id": "13DOrgKjhDRCRaEk8n4TSDZLGTZFDeVl0SeS7z3MMwF0", "tabs": ["Master"]},
    {"id": "fms_4", "name": "4. Checklist FMS",           "sheet_id": "1j5RPy6PgfZqsJc5rtrvxnY5w5z18aOfaFsjEObf-uE0", "tabs": ["Master"]},
    {"id": "fms_5", "name": "5. Return FMS",              "sheet_id": "1P-q37fLC8BXMxG89MaNDmm3FV5UIpPsC9Z_dztUeouY", "tabs": ["RETURNFMS"]},
    {"id": "fms_6", "name": "6. After Sales FMS",         "sheet_id": "1r9FvYToT8K22iT_3YsrOWpxqCblfVOmYKt1X8GQIhLo", "tabs": ["Dashboard"]},
    {"id": "fms_7", "name": "7. Delivery Challan FMS",    "sheet_id": "1fTs8v35jM1nqhiC7QEngP1vgCPt2yMb0L0PPJWWeg8k", "tabs": ["Fms"]},
    {"id": "fms_8", "name": "8. Commission FMS",          "sheet_id": "1DgNrXuzCsasF0VdWionTuW2f1HhzjWPzqjtNrW4dcZo", "tabs": ["Fms"]},
]

# Real team members confirmed by user
PRIMARY_DOERS = ["CRM", "PRAKASH", "AMOL", "LALIT", "MIS", "PC",
                 "SUBHOJIT", "SOUVIK", "TUSHAR", "PREM",
                 "SUSMITA", "HARSH", "RIYA", "SAHA", "JAYANTA", "KARMAKAR", "MEET"]


DATA_CACHE: Dict = {"timestamp": None, "tasks": []}


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────
def cs(val: Any) -> str:
    """Clean string."""
    v = str(val).strip() if val is not None else ""
    return "" if v.upper() in {"#N/A","#REF!","#VALUE!","N/A","NA"} else v

def normalize_doer(raw: str) -> str:
    name = cs(raw).upper()
    if not name or name in {"NA","N/A","-","NONE","0","#N/A","#REF!","UNASSIGNED",""}:
        return "UNASSIGNED"
    MAP = {
        # CRM
        "CRM":"CRM", "SALES/CRM":"CRM", "SALES":"CRM",
        "HINDLIGHTINGCRM@GMAIL.COM":"CRM",
        # PRAKASH
        "PRAKASH":"PRAKASH", "PRAKASH DAS":"PRAKASH",
        # Real doers from master SOD
        "PC":"PC",                                    # Purchase/Courier controller
        "MIS":"MIS",                                  # Management Info System
        "LALIT":"LALIT",                              # Lalit
        "AMOL":"AMOL", "AMAL":"AMOL",
        "SUBHOJIT":"SUBHOJIT", "SUBHOJIT RIYA":"SUBHOJIT",
        "SOUVIK":"SOUVIK", "TUSHAR":"TUSHAR", "PREM":"PREM",
        "SUSMITA":"SUSMITA", "HARSH":"HARSH",
        "RIYA":"RIYA", "SAHA":"SAHA", "AMAL SAHA":"SAHA", "AMOL SAHA":"SAHA",
        "JAYANTA":"JAYANTA", "JAYANTAR":"JAYANTA",
        "KARMAKAR":"KARMAKAR", "MEET":"MEET",
    }
    return MAP.get(name, cs(raw).title())

def parse_date(s: Any) -> Optional[datetime]:
    if not s:
        return None
    v = cs(s)
    if not v or v.upper() in {"NA","N/A","-","#REF!","#N/A","NONE","0","NOT REQUIRED","00/00/0000","#VALUE!"}:
        return None
    v = re.sub(r'([0-9]{1,2}:[0-9]{2})(AM|PM)', r'\1 \2', v, flags=re.IGNORECASE)
    FMT = ["%d/%m/%Y %I:%M %p","%d/%m/%Y %H:%M:%S","%d/%m/%Y %H:%M",
           "%d/%m/%Y","%m/%d/%Y %H:%M:%S","%m/%d/%Y %H:%M","%m/%d/%Y",
           "%Y-%m-%d %H:%M:%S","%Y-%m-%d %H:%M","%Y-%m-%d","%d-%m-%Y"]
    for f in FMT:
        try:
            return datetime.strptime(v, f)
        except ValueError:
            pass
    try:
        from dateutil import parser as dp
        return dp.parse(v, dayfirst=True)
    except Exception:
        return None

def fetch_csv(sheet_id: str, tab: str) -> List[List[str]]:
    url = f"https://docs.google.com/spreadsheets/d/{sheet_id}/gviz/tq?tqx=out:csv&sheet={urllib.parse.quote(tab)}"
    try:
        req = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as r:
            return list(csv.reader(io.StringIO(r.read().decode('utf-8','ignore'))))
    except Exception as e:
        print(f"[FETCH ERROR] {sheet_id}/{tab}: {e}")
        return []

def make_task(tid, fid, fname, tab, row_no, entity, step, doer, planned, actual, raw_st) -> Optional[TaskItem]:
    """Create a TaskItem. Returns None if there's truly nothing to track."""
    st = cs(raw_st).upper()
    if planned is None and actual is None and not st:
        return None

    now = datetime.now()
    completed = actual is not None or st in {"COMPLETED","DONE","CLOSED","WIN","YES"}
    
    if completed:
        if planned and actual:
            # If planned time is midnight (00:00), it means the sheet only stored a date
            # without a specific time. In that case, treat the entire planned day as the
            # deadline (up to end-of-day 23:59:59), so same-day completions are On-Time.
            if planned.hour == 0 and planned.minute == 0:
                effective_deadline = planned.replace(hour=23, minute=59, second=59)
            else:
                effective_deadline = planned + timedelta(minutes=30)  # 30-min grace buffer

            on_time = actual <= effective_deadline
            status = "Completed On-Time" if on_time else "Completed Delayed"
            delay = max(0.0, round((actual - effective_deadline).total_seconds()/3600, 1)) if not on_time else 0.0
        else:
            on_time = True
            status = "Completed On-Time"
            delay = 0.0
        overdue = 0.0
    else:
        on_time = False
        delay = 0.0
        if planned and planned < now:
            status = "Pending Overdue"
            overdue = round((now - planned).total_seconds()/3600, 1)
        else:
            status = "Pending On-Track"
            overdue = 0.0

    return TaskItem(
        id=tid, fms_id=fid, fms_name=fname, tab_name=tab, row_index=row_no,
        entity_name=entity, step_name=step, doer=normalize_doer(doer),
        planned_date=planned.strftime("%Y-%m-%d %H:%M") if planned else None,
        actual_date=actual.strftime("%Y-%m-%d %H:%M") if actual else None,
        status=status, is_completed=completed, is_ontime=on_time,
        delay_hours=delay, overdue_hours=overdue, remarks=raw_st
    )

def g(row, col, default=""):
    """Safe column getter."""
    return row[col] if col < len(row) else default


# ─────────────────────────────────────────────
# Parser: Order to Dispatch  (fms_1)
# ─────────────────────────────────────────────
# CONFIRMED SCHEMA (from deep_audit):
# SOTOPO   – data from row 8 (index 7), meta rows 3-4 confirm step/doer
#   Step1 "Generate & Share SO" doer=CRM:  planned=col7, actual=col8, status=col10
#   Step2 "Order Against PO"    doer=CRM:  planned=col22, actual=col23, status=col25
#
# GeneratePO – data from row 8 (index 7), headers=row7
#   Step1 "PO Generation"          planned=col13,  actual=col14,  status=col17
#   Step2 "Vendor Acknowledgment"  planned=col18,  actual=col19,  status=col21
#   Step3 "Material Production"    planned=col22,  actual=col26,  status=col29
#   Step4 "Dispatch Readiness"     planned=col30,  actual=col35,  status=col37
#   (doer pulled from col16; default = Prakash)
#
# PaymentCRM – data from row 8 (index 7)
#   Step1 "5-day Advance Followup" doer=CRM: planned=col11, actual=col20, status=col10
#   Step2 "Advance Payment Rcpt"   doer=CRM: planned=col15, actual=col20, status=col14
#   Step3 "Balance Payment"        doer=CRM: planned=col19, actual=col22, status=col18
#
# Delivery – data from row 8 (index 7)
#   Step1 "Despatch Approval"      doer=Logistics: planned=col8, actual=col9 if status=DONE else None, status=col11
#   Step2 "Packing & Challan"      doer=Logistics: planned=col12, actual=col13 if st=DONE else None, status=col15
#   Step3 "Dispatch Handover"      doer=Logistics: planned=col16, actual=col17, status=col19
#
# invoiceandpayment – data from row 3 (index 2); headers at row 2
#   col0=timestamp, col1=client, col2=SO, col4=invoice, col9=planned, col10=actual, col12=status

def parse_otd(rows: List[List[str]], tab: str) -> List[TaskItem]:
    tasks = []
    fid, fn = "fms_1", "1. Order to Dispatch FMS"

    if tab == "SOTOPO":
        for i in range(7, len(rows)):
            row = rows[i]
            so = cs(g(row,1)); cust = cs(g(row,5))
            entity = f"{so} – {cust}".strip(" –") if so else None
            if not entity: continue

            # Step 1
            t = make_task(f"OTD-S1-{i}", fid, fn, tab, i+1, entity,
                "Generate & Share SO", "CRM",
                parse_date(g(row,7)), parse_date(g(row,8)), cs(g(row,10)))
            if t: tasks.append(t)

            # Step 2
            t = make_task(f"OTD-S2-{i}", fid, fn, tab, i+1, entity,
                "Order Against Purchase Order", "CRM",
                parse_date(g(row,22)), parse_date(g(row,23)), cs(g(row,25)))
            if t: tasks.append(t)

    elif tab == "GeneratePO":
        # CORRECTED COLUMN MAP (verified from live CSV raw data, PO/26-27/0316):
        # col[1]  = Timestamp (form submission time)
        # col[2]  = PO Number, col[3] = SO Number, col[4] = Vendor Name
        # Step1 PRAKASH "Generate & Fill PO Google Form":
        #   planned=13, actual=14, delay=15, doer=16, status=17
        # Step2 MIS "Update Despatch-Delivery-Shipment Date":
        #   planned=18, actual=19, delay=20, status=21
        #   (col18 = '19/08/2026 04:00PM', col19 = '18/08/2026 07:07PM' → MIS completes EARLY)
        # Step3 AMOL "Issue PO to Supplier":
        #   planned=22, actual=23, delay=24, status=25
        # Step4 PC "Material Availability / Receive":
        #   planned=26, actual=27, delay=28, status=29
        # Step5 PC "Follow Up with Courier Company":
        #   planned=30, actual=31, delay=32, status=33
        # Step6 PC "Dispatch Readiness Confirmation":
        #   planned=34, actual=35, delay=36, status=37
        for i in range(7, len(rows)):
            row = rows[i]
            po = cs(g(row,2)); so = cs(g(row,3)); vendor = cs(g(row,4))
            entity = f"PO:{po} | SO:{so} ({vendor})" if po else None
            if not entity or len(entity) < 5: continue

            specs = [
                ("Generate & Fill PO Google Form",        13, 14, 17, "PRAKASH"),
                ("Update Despatch-Delivery-Shipment Date",18, 19, 21, "MIS"),
                ("Issue PO to Supplier",                  22, 23, 25, "AMOL"),
                ("Material Availability / Receive",       26, 27, 29, "PC"),
                ("Follow Up with Courier Company",        30, 31, 33, "PC"),
                ("Dispatch Readiness Confirmation",       34, 35, 37, "PC"),
            ]
            for k,(step,pc,ac,sc,doer) in enumerate(specs):
                t = make_task(f"GPO-S{k+1}-{i}", fid, fn, tab, i+1, entity,
                    step, doer, parse_date(g(row,pc)), parse_date(g(row,ac)), cs(g(row,sc)))
                if t: tasks.append(t)



    elif tab == "PaymentCRM":
        for i in range(7, len(rows)):
            row = rows[i]
            so = cs(g(row,0)); client = cs(g(row,4))
            entity = f"{so} – {client}".strip(" –") if so else None
            if not entity: continue

            # actual for steps 1&2 is same col20 (payment received date)
            actual_pay = parse_date(g(row,20))

            specs = [
                ("Followup 5 days before shipment for advance payment", 11, actual_pay, 10),
                ("Advance Payment Verification & Receipt",              15, actual_pay, 14),
                ("Balance Payment Followup before Dispatch",            19, parse_date(g(row,22)), 18),
            ]
            for k,(step,pc,act,sc) in enumerate(specs):
                t = make_task(f"PCRM-S{k+1}-{i}", fid, fn, tab, i+1, entity,
                    step, "CRM", parse_date(g(row,pc)), act, cs(g(row,sc)))
                if t: tasks.append(t)

    elif tab == "Delivery":
        # CONFIRMED by user: ALL 3 delivery steps are LALIT/PC's work, NOT MIS.
        # MIS step "Update Despatch-Delivery-Shipment Date" is only in GeneratePO tab.
        # Delivery tab 3 steps (from master SOD):
        #   Step1 → LALIT  (Inform about shipment is packed & ready / courier despatch)
        #   Step2 → PC     (Packing & Delivery Challan Generation)
        #   Step3 → LALIT  (Material Dispatch & Handover)
        for i in range(7, len(rows)):
            row = rows[i]
            so = cs(g(row,0)); name = cs(g(row,2))
            entity = f"{so} – {name}".strip(" –") if so else None
            if not entity: continue

            # Step1: Courier Despatch & Shipment Tracking → LALIT
            s1_st = cs(g(row,11))
            s1_actual = parse_date(g(row,9)) if s1_st.upper() == "DONE" else None
            t = make_task(f"DEL-S1-{i}", fid, fn, tab, i+1, entity,
                "Courier Despatch & Shipment Tracking", "LALIT",
                parse_date(g(row,8)), s1_actual, s1_st)
            if t: tasks.append(t)

            # Step2: Packing & Delivery Challan Generation → PC
            s2_st = cs(g(row,15))
            s2_actual = parse_date(g(row,13)) if s2_st.upper() == "DONE" else None
            t = make_task(f"DEL-S2-{i}", fid, fn, tab, i+1, entity,
                "Packing & Delivery Challan Generation", "PC",
                parse_date(g(row,12)), s2_actual, s2_st)
            if t: tasks.append(t)

            # Step3: Material Dispatch & Handover → LALIT
            t = make_task(f"DEL-S3-{i}", fid, fn, tab, i+1, entity,
                "Material Dispatch & Handover to Client", "LALIT",
                parse_date(g(row,16)), parse_date(g(row,17)), cs(g(row,19)))
            if t: tasks.append(t)


    elif tab == "invoiceandpayment":
        # Headers at row2 (index1): col1=NAME, col2=SO NO, col4=INVOICE NO, col12=Status
        # Data starts row3 (index2)
        # Doer from master SOD: "Generate Invoice+Packaging slip" → CRM
        for i in range(2, len(rows)):
            row = rows[i]
            client = cs(g(row,1)); so = cs(g(row,2)); inv = cs(g(row,4))
            entity = f"{inv} | {so} – {client}".strip(" | –") if (inv or so) else None
            if not entity: continue
            t = make_task(f"INV-{i}", fid, fn, tab, i+1, entity,
                "Generate Invoice + Packaging Slip & Payment Clearance", "CRM",
                parse_date(g(row,9)), parse_date(g(row,10)), cs(g(row,12)))
            if t: tasks.append(t)


    return tasks


# ─────────────────────────────────────────────
# Parser: Order Enquiry  (fms_2)
# ─────────────────────────────────────────────
# CONFIRMED SCHEMA: row1=headers (full step names)
# col0=date, col1=ENQ no, col2=Enquiry Name, col10=Sale, col11=STATUS
# col12=Designer, col13=Salesperson (Lights), col14=Automation Salesperson
# Steps A1-A16: each 5 cols: planned, actual, delay, STEP status, Doer
# Step A1: planned=col23, actual=col24, status=col26, doer=col27
# Step A2: planned=col28, actual=col29, status=col31, doer=col32
# Step A3: planned=col33, actual=col34, status=col36, doer=col37
# etc. +5 each time

def parse_order_enquiry(rows: List[List[str]]) -> List[TaskItem]:
    tasks = []
    fid, fn = "fms_2", "2. Order Enquiry FMS"
    
    # Step definitions: (name, planned_col, actual_col, status_col, doer_col)
    STEPS = [
        ("A1 CAD/BOQ Design",              23, 24, 26, 27),
        ("A2 Budget Sales Call",            28, 29, 31, 32),
        ("A3 Mock-up/Showroom Visit",       33, 34, 36, 37),
        ("A4 Finish CAD Drawing",           38, 39, 41, 42),
        ("A5 BOQ Preparation",              43, 44, 46, 47),
        ("A6 Finish Lighting Quote",        48, 49, 51, 52),
        ("A7 Finish Automation Quote",      53, 54, 56, 57),
        ("A8 Send Quote to Client",         58, 59, 61, 62),
        ("A9 Presentation",                 63, 64, 66, 67),
        ("A10 Follow Up",                   68, 69, 71, 72),
        ("A11 Advance Payment",             73, 74, 76, 77),
        ("A12 Revised CAD Drawing",         78, 79, 81, 82),
        ("A13 Revised Lighting Quote",      83, 84, 86, 87),
        ("A14 Revised Automation Quote",    88, 89, 91, 92),
        ("A15 Send Revised Quote",          93, 94, 96, 97),
        ("A16 Follow Up Revised Quote",     98, 99, 101, 102),
    ]
    
    for i in range(1, len(rows)):
        row = rows[i]
        enq = cs(g(row,1)); name = cs(g(row,2))
        if not enq and not name: continue
        entity = f"{enq} – {name}".strip(" –")
        
        for step_name, pc, ac, sc, dc in STEPS:
            doer = cs(g(row,dc)) or cs(g(row,13)) or "Sales Team"
            t = make_task(f"ENQ-{i}-{pc}", fid, fn, "MASTERSHEET", i+1, entity,
                step_name, doer, parse_date(g(row,pc)), parse_date(g(row,ac)), cs(g(row,sc)))
            if t: tasks.append(t)

    return tasks


# ─────────────────────────────────────────────
# Parser: Delegation  (fms_3)
# ─────────────────────────────────────────────
# CONFIRMED: data from row1 (index 0)
# col0=ID, col1=Doer, col2=Task, col3=Assigned date, col4=Due date,
# col5=Exp complete, col6=Actual complete, col7=Actual2, col8=delay, col9=Status

def parse_delegation(rows: List[List[str]]) -> List[TaskItem]:
    tasks = []
    fid, fn = "fms_3", "3. Delegation FMS"
    for i in range(1, len(rows)):
        row = rows[i]
        task_id = cs(g(row,0)); doer = cs(g(row,1)); desc = cs(g(row,2))
        if not desc: continue
        entity = f"#{task_id}: {desc}" if task_id else desc
        planned = parse_date(g(row,4)) or parse_date(g(row,5))
        actual = parse_date(g(row,6)) or parse_date(g(row,7))
        status = cs(g(row,9))
        t = make_task(f"DEL-{i}", fid, fn, "Master", i+1, entity,
            desc, doer, planned, actual, status)
        if t: tasks.append(t)
    return tasks


# ─────────────────────────────────────────────
# Parser: Checklist  (fms_4)
# ─────────────────────────────────────────────
# CONFIRMED: data from row1 (index0)
# col0=Doer, col3=ID, col5=Task description, col6=Planned date, col7=Actual date

def parse_checklist(rows: List[List[str]]) -> List[TaskItem]:
    tasks = []
    fid, fn = "fms_4", "4. Checklist FMS"
    for i in range(1, len(rows)):
        row = rows[i]
        doer = cs(g(row,0)); tid = cs(g(row,3)); desc = cs(g(row,5))
        if not desc: continue
        entity = f"#{tid}: {desc}" if tid else desc
        planned = parse_date(g(row,6))
        actual = parse_date(g(row,7))
        status = "Completed" if actual else "Pending"
        t = make_task(f"CHK-{i}", fid, fn, "Master", i+1, entity,
            desc, doer, planned, actual, status)
        if t: tasks.append(t)
    return tasks


# ─────────────────────────────────────────────
# Parser: Return FMS  (fms_5)
# ─────────────────────────────────────────────
# CONFIRMED: meta rows 1-6, data from row7 (index6)
# Row4 (index3): doer at col10 = PRAKASH
# col1=Return key, col2=SO, col4=Site, col6=planned, col7=actual, col10=step "DC return/credit note"

def parse_return(rows: List[List[str]]) -> List[TaskItem]:
    tasks = []
    fid, fn = "fms_5", "5. Return FMS"
    for i in range(6, len(rows)):
        row = rows[i]
        rk = cs(g(row,1)); so = cs(g(row,2)); site = cs(g(row,4))
        if not rk and not so: continue
        entity = f"{rk} | {so} – {site}".strip(" | –")
        planned = parse_date(g(row,6)) or parse_date(g(row,10))
        actual = parse_date(g(row,7)) or parse_date(g(row,11))
        t = make_task(f"RET-{i}", fid, fn, "RETURNFMS", i+1, entity,
            "Return Material Processing & Credit Note", "PRAKASH",
            planned, actual, "Completed" if actual else "Pending")
        if t: tasks.append(t)
    return tasks


# ─────────────────────────────────────────────
# Parser: After Sales  (fms_6)
# ─────────────────────────────────────────────
# CONFIRMED Dashboard: data from row2 (index1)
# col0=Issue ID, col1=Site, col2=Type, col3=Reported date, col4=Status, col5=Planned visit,
# col6=Doer, col12=Resolved date

def parse_after_sales(rows: List[List[str]], tab: str) -> List[TaskItem]:
    tasks = []
    fid, fn = "fms_6", "6. After Sales FMS"
    if tab != "Dashboard": return tasks
    for i in range(1, len(rows)):
        row = rows[i]
        iss = cs(g(row,0)); site = cs(g(row,1))
        if not iss and not site: continue
        entity = f"{iss} – {site}".strip(" –")
        doer = cs(g(row,6)) or "Service Team"
        planned = parse_date(g(row,5)) or parse_date(g(row,3))
        actual = parse_date(g(row,12))
        status = cs(g(row,4))
        t = make_task(f"AFS-{i}", fid, fn, tab, i+1, entity,
            "After Sales Service Visit & Resolution", doer,
            planned, actual, status)
        if t: tasks.append(t)
    return tasks


# ─────────────────────────────────────────────
# Parser: Delivery Challan  (fms_7)
# ─────────────────────────────────────────────
# CONFIRMED: meta rows 1-6, data from row7 (index6)
# col0=ID, col2=SO/Name, col4=DC no, col17=Doer(CRM)
# Planned/Actual need to find from actual data rows

def parse_dc(rows: List[List[str]]) -> List[TaskItem]:
    # CONFIRMED SCHEMA (deep_audit):
    # Headers at row6 (index5): col0=Unique Key, col2=SO NAME, col3=SO NO, col4=DC NO
    #   col13=Status, col17=DOER, col21=Status, col26=Planned, col27=Actual, col29=Status
    # Data from row7 (index6)
    tasks = []
    fid, fn = "fms_7", "7. Delivery Challan FMS"
    steps = [
        ("DC Dispatch Initiation",       14, 15, 13),
        ("DC Material Verification",     18, 19, 21),
        ("DC Physical Delivery & Ack",   22, 23, 29),
        ("DC Auto-MIAC Followup",        26, 27, 29),
    ]
    for i in range(6, len(rows)):
        row = rows[i]
        kid = cs(g(row,0)); so_name = cs(g(row,2)); dc = cs(g(row,4))
        doer = cs(g(row,17)) or "CRM"
        entity = f"{dc} | {kid} – {so_name}".strip(" | –") if (dc or kid) else None
        if not entity: continue
        for k, (step, pc, ac, sc) in enumerate(steps):
            t = make_task(f"DC-S{k+1}-{i}", fid, fn, "Fms", i+1, entity,
                step, doer,
                parse_date(g(row, pc)), parse_date(g(row, ac)), cs(g(row, sc)))
            if t: tasks.append(t)
    return tasks


# ─────────────────────────────────────────────
# Parser: Commission  (fms_8)
# ─────────────────────────────────────────────
# CONFIRMED: data from row3 (index2)
# col0=date, col1=ENQ no, col2=Name, col7=status, col10=planned, col11=actual

def parse_commission(rows: List[List[str]]) -> List[TaskItem]:
    tasks = []
    fid, fn = "fms_8", "8. Commission FMS"
    for i in range(2, len(rows)):
        row = rows[i]
        enq = cs(g(row,1)); name = cs(g(row,2))
        if not enq and not name: continue
        entity = f"{enq} – {name}".strip(" –")
        planned = parse_date(g(row,10)) or parse_date(g(row,0))
        actual = parse_date(g(row,11)) or parse_date(g(row,15))
        status = cs(g(row,7))
        t = make_task(f"COMM-{i}", fid, fn, "Fms", i+1, entity,
            "Commission Calculation & Settlement", "ACCOUNTS",
            planned, actual, status)
        if t: tasks.append(t)
    return tasks


# ─────────────────────────────────────────────
# Main fetch + parse
# ─────────────────────────────────────────────
def fetch_and_parse_all_sheets(force_refresh: bool = False) -> List[TaskItem]:
    global DATA_CACHE
    now = datetime.now()
    if not force_refresh and DATA_CACHE["timestamp"] and (now - DATA_CACHE["timestamp"]).total_seconds() < 600:
        return DATA_CACHE["tasks"]

    all_tasks: List[TaskItem] = []

    def process_tab(cfg, tab):
        rows = fetch_csv(cfg["sheet_id"], tab)
        fid = cfg["id"]
        if fid == "fms_1": return parse_otd(rows, tab)
        if fid == "fms_2": return parse_order_enquiry(rows)
        if fid == "fms_3": return parse_delegation(rows)
        if fid == "fms_4": return parse_checklist(rows)
        if fid == "fms_5": return parse_return(rows)
        if fid == "fms_6": return parse_after_sales(rows, tab)
        if fid == "fms_7": return parse_dc(rows)
        if fid == "fms_8": return parse_commission(rows)
        return []

    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as ex:
        futures = {ex.submit(process_tab, cfg, tab): (cfg, tab)
                   for cfg in FMS_CONFIGS for tab in cfg["tabs"]}
        for fut in concurrent.futures.as_completed(futures):
            try:
                all_tasks.extend(fut.result())
            except Exception as e:
                cfg, tab = futures[fut]
                print(f"[ERROR] {cfg['name']}/{tab}: {e}")

    DATA_CACHE["timestamp"] = now
    DATA_CACHE["tasks"] = all_tasks
    print(f"[INFO] Loaded {len(all_tasks)} tasks from all 8 FMS sheets.")
    return all_tasks


# ─────────────────────────────────────────────
# Report Generation
# ─────────────────────────────────────────────
def generate_report(
    fms_filter: str = "ALL",
    date_preset: str = "ALL_TIME",
    custom_start: Optional[str] = None,
    custom_end: Optional[str] = None,
    doer_filter: str = "ALL",
    status_filter: str = "ALL",
    force_refresh: bool = False
) -> AggregatedReport:

    tasks = fetch_and_parse_all_sheets(force_refresh=force_refresh)
    now = datetime.now()
    today = datetime(now.year, now.month, now.day)

    start_dt = end_dt = None
    if custom_start or custom_end:
        if custom_start:
            s = parse_date(custom_start)
            if s: start_dt = datetime(s.year, s.month, s.day, 0, 0, 0)
        if custom_end:
            e = parse_date(custom_end)
            if e: end_dt = datetime(e.year, e.month, e.day, 23, 59, 59)
    elif date_preset == "TODAY":
        start_dt = today
        end_dt = today.replace(hour=23, minute=59, second=59)
    elif date_preset == "YESTERDAY":
        d = today - timedelta(days=1)
        start_dt = d
        end_dt = d.replace(hour=23, minute=59, second=59)
    elif date_preset == "THIS_WEEK":
        # Monday of current week to today
        mon = today - timedelta(days=today.weekday())
        start_dt = mon
        end_dt = today.replace(hour=23, minute=59, second=59)
    elif date_preset == "LAST_WEEK":
        # Monday to Sunday of previous week
        last_mon = today - timedelta(days=today.weekday() + 7)
        last_sun = last_mon + timedelta(days=6)
        start_dt = last_mon
        end_dt = last_sun.replace(hour=23, minute=59, second=59)

    filtered: List[TaskItem] = []
    for t in tasks:
        if fms_filter != "ALL" and t.fms_id != fms_filter: continue
        if doer_filter != "ALL" and normalize_doer(t.doer) != normalize_doer(doer_filter): continue
        if status_filter != "ALL":
            if status_filter == "COMPLETED" and not t.is_completed: continue
            elif status_filter == "PENDING" and t.is_completed: continue
            elif status_filter == "ON_TIME" and not t.is_ontime: continue
            elif status_filter == "DELAYED" and (t.is_ontime or not t.is_completed): continue
            elif status_filter == "OVERDUE" and t.status != "Pending Overdue": continue
        if start_dt or end_dt:
            p = parse_date(t.planned_date)
            a = parse_date(t.actual_date)
            in_range = (a and (not start_dt or a >= start_dt) and (not end_dt or a <= end_dt)) or \
                       (p and (not start_dt or p >= start_dt) and (not end_dt or p <= end_dt))
            if not in_range: continue
        filtered.append(t)

    # Known doers
    known = set(normalize_doer(t.doer) for t in tasks if t.doer) | set(PRIMARY_DOERS)
    known.discard("UNASSIGNED")
    available_doers = sorted(list(known))

    # Doer metrics
    doer_dict: Dict[str, DoerMetric] = {d: DoerMetric(doer=d) for d in available_doers}
    for t in filtered:
        d = normalize_doer(t.doer)
        if d not in doer_dict: doer_dict[d] = DoerMetric(doer=d)
        dm = doer_dict[d]
        dm.total_assigned += 1
        if t.is_completed:
            dm.total_completed += 1
            if t.is_ontime: dm.ontime_completed += 1
            else: dm.delayed_completed += 1
        else:
            dm.total_pending += 1
            if t.status == "Pending Overdue": dm.pending_overdue += 1

    doer_list = []
    for dm in doer_dict.values():
        dm.score_percentage = round(dm.ontime_completed / dm.total_assigned * 100, 1) if dm.total_assigned else 0.0
        doer_list.append(dm)
    doer_list.sort(key=lambda x: (-x.total_assigned, -x.score_percentage))

    # FMS summaries
    fms_dict = {c["id"]: FMSReportSummary(fms_id=c["id"], fms_name=c["name"]) for c in FMS_CONFIGS}
    for t in filtered:
        if t.fms_id in fms_dict:
            fs = fms_dict[t.fms_id]
            fs.total_tasks += 1
            if t.is_completed:
                fs.completed_tasks += 1
                if t.is_ontime: fs.ontime_tasks += 1
            else: fs.pending_tasks += 1
    fms_list = []
    for fs in fms_dict.values():
        if fs.total_tasks: fs.overall_score = round(fs.ontime_tasks / fs.total_tasks * 100, 1)
        fms_list.append(fs)

    tot = len(filtered)
    comp = sum(1 for t in filtered if t.is_completed)
    ontime = sum(1 for t in filtered if t.is_completed and t.is_ontime)
    delayed = sum(1 for t in filtered if t.is_completed and not t.is_ontime)
    pending = sum(1 for t in filtered if not t.is_completed)
    overdue = sum(1 for t in filtered if t.status == "Pending Overdue")

    fms_name = next((c["name"] for c in FMS_CONFIGS if c["id"] == fms_filter), "All 8 FMS (Combined Report)")

    return AggregatedReport(
        fms_id=fms_filter, fms_name=fms_name,
        date_preset=date_preset,
        start_date=start_dt.strftime("%Y-%m-%d") if start_dt else None,
        end_date=end_dt.strftime("%Y-%m-%d") if end_dt else None,
        total_assigned=tot, total_completed=comp,
        ontime_completed=ontime, delayed_completed=delayed,
        total_pending=pending, pending_overdue=overdue,
        overall_score_percentage=round(ontime/tot*100,1) if tot else 0.0,
        doer_metrics=doer_list, fms_summaries=fms_list,
        task_items=filtered,
        available_doers=available_doers,
        available_fms=[{"id": c["id"], "name": c["name"]} for c in FMS_CONFIGS]
    )
