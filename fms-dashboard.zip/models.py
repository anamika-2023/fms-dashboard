from dataclasses import dataclass, field
from typing import List, Optional, Dict
from datetime import datetime, date

@dataclass
class TaskItem:
    id: str
    fms_id: str
    fms_name: str
    tab_name: str
    row_index: int
    entity_name: str  # Customer / SO / Enquiry / Task name / Site Name
    step_name: str
    doer: str
    planned_date: Optional[str] = None
    actual_date: Optional[str] = None
    status: str = "Pending"  # "Completed On-Time", "Completed Delayed", "Pending On-Track", "Pending Overdue"
    is_completed: bool = False
    is_ontime: bool = False
    delay_hours: float = 0.0
    overdue_hours: float = 0.0
    remarks: str = ""

@dataclass
class DoerMetric:
    doer: str
    total_assigned: int = 0
    total_completed: int = 0
    ontime_completed: int = 0
    delayed_completed: int = 0
    total_pending: int = 0
    pending_overdue: int = 0
    score_percentage: float = 0.0

@dataclass
class FMSReportSummary:
    fms_id: str
    fms_name: str
    total_tasks: int = 0
    completed_tasks: int = 0
    ontime_tasks: int = 0
    pending_tasks: int = 0
    overall_score: float = 0.0
    doers_count: int = 0

@dataclass
class AggregatedReport:
    fms_id: str
    fms_name: str
    date_preset: str
    start_date: Optional[str]
    end_date: Optional[str]
    total_assigned: int = 0
    total_completed: int = 0
    ontime_completed: int = 0
    delayed_completed: int = 0
    total_pending: int = 0
    pending_overdue: int = 0
    overall_score_percentage: float = 0.0
    doer_metrics: List[DoerMetric] = field(default_factory=list)
    fms_summaries: List[FMSReportSummary] = field(default_factory=list)
    task_items: List[TaskItem] = field(default_factory=list)
    available_doers: List[str] = field(default_factory=list)
    available_fms: List[Dict[str, str]] = field(default_factory=list)
